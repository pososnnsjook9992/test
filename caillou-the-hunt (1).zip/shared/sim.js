'use strict';
/**
 * Shared movement simulation. The SAME file runs on the server (authoritative) and in the
 * browser (client-side prediction), so both sides compute identical results from identical inputs.
 *
 * Coordinates: x = east, z = south, y = up (Three.js convention). Yaw 0 looks toward -z.
 * One command = one fixed simulation tick, so a client can never move faster than the tick rate allows.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.HuntSim = factory();
})(typeof self !== 'undefined' ? self : globalThis, function () {
  const F = Object.freeze({ SPRINT: 1, CROUCH: 2, JUMP: 4, WALK: 8, INTERACT: 16, ATTACK: 32 });
  const EPS = 1e-4;

  const DEFAULT_RULES = {
    tickHz: 30,
    snapshotEvery: 2, // server sends a snapshot every N ticks (15 Hz by default)
    player: { halfWidth: 0.35, heightStand: 1.8, heightCrouch: 1.2, eyeStand: 1.65, eyeCrouch: 1.1, stepHeight: 0.3, gravity: 20, jumpSpeed: 6.2 },
    survivor: {
      walk: 2.4, run: 4.2, sprint: 6.0, crouch: 1.7,
      health: 100,
      stamina: { max: 100, drainPerSec: 22, regenPerSec: 14, regenDelayMs: 1000, exhaustRecoverAt: 25 },
      hitHaste: { ms: 1500, mult: 1.25 },
    },
    killer: { walk: 2.6, run: 4.6, crouch: 1.9 },
    interact: { range: 2.2, minFacingDot: 0.2 },
    objective: { workSeconds: 25 },
    hiding: { reenterLockoutMs: 4000 },
    attack: { range: 2.3, halfAngleDeg: 55, vertical: 1.3, leniency: 0.3, damage: 34, windupMs: 200, cooldownMs: 1400, hitCooldownMs: 2200 },
  };

  const isPlain = (v) => v && typeof v === 'object' && !Array.isArray(v);
  function merge(base, over) {
    const out = {};
    for (const k of Object.keys(base)) out[k] = isPlain(base[k]) ? merge(base[k], isPlain(over && over[k]) ? over[k] : {}) : (over && over[k] !== undefined ? over[k] : base[k]);
    return out;
  }
  function checkNumbers(o, path) {
    for (const [k, v] of Object.entries(o)) {
      if (isPlain(v)) checkNumbers(v, `${path}.${k}`);
      else if (typeof v !== 'number' || !Number.isFinite(v) || v < 0) throw new Error(`${path}.${k} must be a finite non-negative number`);
    }
  }
  /** Returns a complete rules object; throws on invalid overrides. */
  function mergeRules(overrides) {
    const rules = merge(DEFAULT_RULES, overrides || {});
    checkNumbers(rules, 'rules');
    if (rules.tickHz < 1 || rules.snapshotEvery < 1) throw new Error('rules.tickHz and rules.snapshotEvery must be >= 1');
    return rules;
  }
  const msToTicks = (ms, hz) => (ms <= 0 ? 0 : Math.max(1, Math.round((ms * hz) / 1000)));

  function createPlayerState(spawn, role, rules) {
    return {
      x: spawn.x, y: spawn.y || 0, z: spawn.z, vy: 0,
      yaw: spawn.yaw || 0, pitch: 0,
      onGround: true, crouch: false,
      stamina: role === 'survivor' ? rules.survivor.stamina.max : 0,
      exhausted: false, regen: 0, haste: 0,
    };
  }
  const cloneState = (s) => ({ ...s });

  function overlapsBox(x, y, z, hw, h, b) {
    return x + hw > b.min[0] && x - hw < b.max[0] && z + hw > b.min[2] && z - hw < b.max[2] && y + h > b.min[1] && y < b.max[1];
  }
  function anyOverlap(map, x, y, z, hw, h) {
    for (const b of map.colliders) if (overlapsBox(x, y, z, hw, h, b)) return true;
    return false;
  }

  function moveHoriz(s, axis, d, map, h, P, canStep) {
    if (d === 0) return;
    const hw = P.halfWidth;
    const ai = axis === 'x' ? 0 : 2;
    s[axis] += d;
    for (const b of map.colliders) {
      if (!overlapsBox(s.x, s.y, s.z, hw, h, b)) continue;
      const rise = b.max[1] - s.y;
      if (canStep && rise > 0 && rise <= P.stepHeight + EPS && !anyOverlap(map, s.x, b.max[1], s.z, hw, h)) {
        s.y = b.max[1];
        continue;
      }
      s[axis] = d > 0 ? b.min[ai] - hw - EPS : b.max[ai] + hw + EPS;
    }
  }

  function moveVertical(s, d, map, h, P) {
    const hw = P.halfWidth;
    const prevY = s.y;
    s.y += d;
    s.onGround = false;
    if (d <= 0) {
      let ground = 0;
      for (const b of map.colliders) {
        if (s.x + hw > b.min[0] && s.x - hw < b.max[0] && s.z + hw > b.min[2] && s.z - hw < b.max[2] && b.max[1] <= prevY + EPS && b.max[1] > ground) ground = b.max[1];
      }
      if (s.y <= ground) { s.y = ground; s.vy = 0; s.onGround = true; }
    } else {
      for (const b of map.colliders) {
        if (s.x + hw > b.min[0] && s.x - hw < b.max[0] && s.z + hw > b.min[2] && s.z - hw < b.max[2] && b.min[1] >= prevY + h - EPS && s.y + h > b.min[1]) {
          s.y = b.min[1] - h; s.vy = 0;
        }
      }
    }
  }

  /** Advance one player by exactly one tick. cmd = { x, z (-1|0|1), y (yaw), p (pitch), f (flags) }. */
  function stepPlayer(s, cmd, map, rules, role) {
    const dt = 1 / rules.tickHz;
    const P = rules.player;
    const isKiller = role === 'killer';
    const cfg = isKiller ? rules.killer : rules.survivor;
    const f = cmd.f | 0;
    s.yaw = cmd.y; s.pitch = cmd.p;

    const wantCrouch = (f & F.CROUCH) !== 0;
    if (wantCrouch) s.crouch = true;
    else if (s.crouch && !anyOverlap(map, s.x, s.y, s.z, P.halfWidth, P.heightStand)) s.crouch = false;
    const h = s.crouch ? P.heightCrouch : P.heightStand;

    const mx = cmd.x, mz = cmd.z;
    const moving = mx !== 0 || mz !== 0;
    let speed;
    let sprinting = false;
    if (s.crouch) speed = cfg.crouch;
    else if (f & F.WALK) speed = cfg.walk;
    else if (!isKiller && (f & F.SPRINT) && mz > 0 && !s.exhausted && s.stamina > 0) { speed = cfg.sprint; sprinting = true; }
    else speed = cfg.run;
    if (!isKiller && s.haste > 0) { speed *= rules.survivor.hitHaste.mult; s.haste--; }

    if (!isKiller) {
      const st = rules.survivor.stamina;
      if (sprinting && moving) {
        s.stamina -= st.drainPerSec * dt;
        s.regen = msToTicks(st.regenDelayMs, rules.tickHz);
        if (s.stamina <= 0) { s.stamina = 0; s.exhausted = true; }
      } else if (s.regen > 0) s.regen--;
      else s.stamina = Math.min(st.max, s.stamina + st.regenPerSec * dt);
      if (s.exhausted && s.stamina >= st.exhaustRecoverAt) s.exhausted = false;
    }

    const sin = Math.sin(s.yaw), cos = Math.cos(s.yaw);
    let wx = mx * cos - mz * sin;
    let wz = -mx * sin - mz * cos;
    const len = Math.hypot(wx, wz);
    if (len > 1) { wx /= len; wz /= len; }

    if ((f & F.JUMP) && s.onGround && !s.crouch) { s.vy = P.jumpSpeed; s.onGround = false; }

    const canStep = s.onGround;
    moveHoriz(s, 'x', wx * speed * dt, map, h, P, canStep);
    moveHoriz(s, 'z', wz * speed * dt, map, h, P, canStep);
    s.vy -= P.gravity * dt;
    moveVertical(s, s.vy * dt, map, h, P);

    const b = map.bounds;
    s.x = Math.min(Math.max(s.x, b.min[0] + P.halfWidth), b.max[0] - P.halfWidth);
    s.z = Math.min(Math.max(s.z, b.min[1] + P.halfWidth), b.max[1] - P.halfWidth);
    return sprinting;
  }

  /** True when the straight XZ segment a->b is blocked by a collider at height y (colliders with ref === ignoreRef are skipped). */
  function segmentBlocked(map, ax, az, bx, bz, y, ignoreRef) {
    const dx = bx - ax, dz = bz - az;
    for (const b of map.colliders) {
      if (y < b.min[1] || y > b.max[1]) continue;
      if (ignoreRef && b.ref === ignoreRef) continue;
      let t0 = 0, t1 = 1, hit = true;
      for (const [a, d, lo, hi] of [[ax, dx, b.min[0], b.max[0]], [az, dz, b.min[2], b.max[2]]]) {
        if (Math.abs(d) < 1e-9) { if (a < lo || a > hi) { hit = false; break; } continue; }
        let ta = (lo - a) / d, tb = (hi - a) / d;
        if (ta > tb) [ta, tb] = [tb, ta];
        t0 = Math.max(t0, ta); t1 = Math.min(t1, tb);
        if (t0 > t1) { hit = false; break; }
      }
      if (hit) return true;
    }
    return false;
  }

  /** Distance on the XZ plane from a point to a collider box (0 if inside). */
  function distToBox(px, pz, b) {
    const cx = Math.min(Math.max(px, b.min[0]), b.max[0]);
    const cz = Math.min(Math.max(pz, b.min[2]), b.max[2]);
    return Math.hypot(px - cx, pz - cz);
  }

  return { F, EPS, DEFAULT_RULES, mergeRules, msToTicks, createPlayerState, cloneState, stepPlayer, overlapsBox, anyOverlap, segmentBlocked, distToBox };
});
