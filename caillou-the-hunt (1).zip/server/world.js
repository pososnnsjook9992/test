'use strict';
const Sim = require('../shared/sim');
const { F } = Sim;

const MAX_QUEUE = 8;
const r3 = (v) => Math.round(v * 1000) / 1000;
const r4 = (v) => Math.round(v * 10000) / 10000;

/**
 * The authoritative gameplay state of ONE match. Clients only ever send input commands
 * (axes, look direction, button flags). Everything else -- positions, stamina, health,
 * interaction results, hits, escapes -- is decided here.
 *
 * hooks: { onEliminated(playerId), onEscaped(playerId) }
 */
class World {
  constructor({ map, rules, players, hooks }) {
    this.map = map;
    this.rules = rules;
    this.hooks = hooks || {};
    this.tick = 0;
    this.events = [];
    this.exitsOpen = false;
    this.completed = 0;
    const hz = rules.tickHz;
    this.t = {
      windup: Sim.msToTicks(rules.attack.windupMs, hz),
      cooldown: Sim.msToTicks(rules.attack.cooldownMs, hz),
      hitCooldown: Sim.msToTicks(rules.attack.hitCooldownMs, hz),
      haste: Sim.msToTicks(rules.survivor.hitHaste.ms, hz),
      lockout: Sim.msToTicks(rules.hiding.reenterLockoutMs, hz),
    };
    this.objectives = map.objectives.map((o) => ({ ...o, workSeconds: o.workSeconds ?? rules.objective.workSeconds, progress: 0, done: false, workers: new Set(), contributors: new Set() }));
    this.spots = map.hidingSpots.map((h) => ({ ...h, occupant: null }));
    this.players = new Map();
    for (const p of players) {
      this.players.set(p.id, {
        id: p.id, role: p.role,
        sim: Sim.createPlayerState(p.spawn, p.role, rules),
        health: p.role === 'survivor' ? rules.survivor.health : 0,
        queue: [], lastSeq: 0, maxSeq: 0, prevFlags: 0, held: false,
        hidden: null, working: null, eliminated: false, escaped: false, removed: false,
        attackReady: 0, windup: 0, lockoutUntil: 0, moving: false, sprinting: false,
        stats: { objectivesCompleted: 0, hitsLanded: 0 },
      });
    }
  }

  // ---------- helpers ----------
  _inPlay(p) { return !p.removed && !p.eliminated && !p.escaped; }
  _emit(e) { this.events.push(e); }
  flushEvents() { const e = this.events; this.events = []; return e; }

  /** Accept validated command objects from the network layer. Strictly ordered, bounded queue. */
  pushInput(id, cmds) {
    const p = this.players.get(id);
    if (!p || !this._inPlay(p)) return 0;
    let accepted = 0;
    for (const c of cmds) {
      if (c.s <= p.maxSeq) continue; // duplicate / replay / out of order
      p.maxSeq = c.s;
      if (p.queue.length >= MAX_QUEUE) p.queue.shift();
      p.queue.push(c);
      accepted++;
    }
    return accepted;
  }

  /** After a reconnect: drop stale queued input; the client continues from `maxSeq`. */
  resetInput(id) {
    const p = this.players.get(id);
    if (!p) return 0;
    p.queue.length = 0;
    p.maxSeq = p.lastSeq;
    return p.maxSeq;
  }

  /** Takes a player out of play (used by Match for eliminations/escapes decided elsewhere). Idempotent. */
  markOut(id, kind) {
    const p = this.players.get(id);
    if (!p) return;
    if (kind === 'eliminated') p.eliminated = true;
    if (kind === 'escaped') p.escaped = true;
    this._stopWork(p);
    this._freeSpot(p);
  }

  seqOf(id) { const p = this.players.get(id); return p ? p.maxSeq : 0; }

  removePlayer(id) {
    const p = this.players.get(id);
    if (!p || p.removed) return;
    this._stopWork(p);
    this._freeSpot(p);
    p.removed = true;
  }

  // ---------- simulation ----------
  step() {
    this.tick++;
    for (const p of this.players.values()) if (this._inPlay(p)) this._stepPlayer(p);
    this._updateObjectives();
    this._updateAttacks();
    this._checkExits();
  }

  _stepPlayer(p) {
    // Strictly one command per tick: speeding up the client clock or flooding input gains nothing.
    const cmd = p.queue.shift();
    if (!cmd) return;
    p.lastSeq = cmd.s;
    const before = { x: p.sim.x, z: p.sim.z };
    if (p.hidden) { p.sim.yaw = cmd.y; p.sim.pitch = cmd.p; p.sprinting = false; }
    else p.sprinting = Sim.stepPlayer(p.sim, cmd, this.map, this.rules, p.role);
    p.moving = Math.abs(p.sim.x - before.x) + Math.abs(p.sim.z - before.z) > 1e-4;

    const f = cmd.f;
    const pressed = f & ~p.prevFlags;
    p.prevFlags = f;
    p.held = (f & F.INTERACT) !== 0;
    if (pressed & F.INTERACT) this._interactPress(p);
    if ((pressed & F.ATTACK) && p.role === 'killer') this._startAttack(p);
  }

  _forward(p) { return [-Math.sin(p.sim.yaw), -Math.cos(p.sim.yaw)]; }

  /** Nearest objective/locker in reach, in front of the player, with a clear line (no wall in between). */
  _findTarget(p, wantObjectives) {
    const R = this.rules.interact;
    const [fx, fz] = this._forward(p);
    let best = null;
    const consider = (kind, ref, box, cx, cz) => {
      const d = Sim.distToBox(p.sim.x, p.sim.z, box);
      if (d > R.range) return;
      if (Math.abs(p.sim.y - box.min[1]) > 1.8) return;
      const dx = cx - p.sim.x, dz = cz - p.sim.z, len = Math.hypot(dx, dz);
      if (len > 0.9 && (dx * fx + dz * fz) / len < R.minFacingDot) return;
      if (Sim.segmentBlocked(this.map, p.sim.x, p.sim.z, cx, cz, p.sim.y + 1.0, ref)) return;
      if (!best || d < best.d) best = { kind, ref, d };
    };
    const boxOf = (ref) => this.map.colliders.find((c) => c.ref === ref);
    if (wantObjectives) for (const o of this.objectives) if (!o.done) consider('objective', o.id, boxOf(o.id), o.x, o.z);
    for (const s of this.spots) consider('spot', s.id, boxOf(s.id), s.x, s.z);
    return best;
  }

  _interactPress(p) {
    if (p.role === 'survivor') {
      if (p.hidden) return this._unhide(p);
      const t = this._findTarget(p, true);
      if (!t) return;
      if (t.kind === 'objective') this._beginWork(p, this.objectives.find((o) => o.id === t.ref));
      else this._hide(p, this.spots.find((s) => s.id === t.ref));
    } else {
      // The killer searches lockers: an occupant is pulled out into the open.
      const t = this._findTarget(p, false);
      const spot = t && this.spots.find((s) => s.id === t.ref);
      if (spot && spot.occupant) this._eject(spot);
    }
  }

  // ----- objectives -----
  _beginWork(p, obj) {
    if (!obj || obj.done) return;
    this._stopWork(p);
    p.working = obj.id;
    obj.workers.add(p.id);
  }
  _stopWork(p) {
    if (!p.working) return;
    const o = this.objectives.find((x) => x.id === p.working);
    if (o) o.workers.delete(p.id);
    p.working = null;
  }
  _updateObjectives() {
    const dt = 1 / this.rules.tickHz;
    for (const o of this.objectives) {
      if (o.done) continue;
      const box = this.map.colliders.find((c) => c.ref === o.id);
      for (const id of [...o.workers]) {
        const p = this.players.get(id);
        const ok = p && this._inPlay(p) && !p.hidden && p.held && Sim.distToBox(p.sim.x, p.sim.z, box) <= this.rules.interact.range + 0.5;
        if (!ok) { if (p) this._stopWork(p); else o.workers.delete(id); continue; }
        o.progress += dt;
        o.contributors.add(id);
      }
      if (o.progress >= o.workSeconds) this._complete(o);
    }
  }
  _complete(o) {
    o.done = true; // set before anything else: an objective can only ever be completed (and rewarded) once
    o.progress = o.workSeconds;
    for (const id of o.contributors) { const p = this.players.get(id); if (p) p.stats.objectivesCompleted++; }
    for (const id of [...o.workers]) { const p = this.players.get(id); if (p) p.working = null; }
    o.workers.clear();
    this.completed++;
    this._emit({ e: 'obj', id: o.id });
    if (!this.exitsOpen && this.completed >= this.map.exitUnlock) { this.exitsOpen = true; this._emit({ e: 'exits' }); }
  }

  // ----- hiding -----
  _hide(p, spot) {
    if (!spot || spot.occupant || this.tick < p.lockoutUntil) return;
    this._stopWork(p);
    spot.occupant = p.id;
    p.hidden = spot.id;
    p.sim.x = spot.x; p.sim.z = spot.z; p.sim.vy = 0; p.sim.crouch = false;
    p.sim.yaw = spot.yaw;
  }
  _unhide(p) {
    const spot = this.spots.find((s) => s.id === p.hidden);
    if (!spot) { p.hidden = null; return; }
    this._leaveSpot(p, spot);
  }
  _eject(spot) {
    const p = this.players.get(spot.occupant);
    if (p) { this._leaveSpot(p, spot); p.lockoutUntil = this.tick + this.t.lockout; this._emit({ e: 'eject', id: p.id }); }
  }
  _leaveSpot(p, spot) {
    spot.occupant = null;
    p.hidden = null;
    p.sim.x = spot.exitX; p.sim.z = spot.exitZ; p.sim.y = 0; p.sim.vy = 0; p.sim.onGround = true;
  }
  _freeSpot(p) {
    if (!p.hidden) return;
    const spot = this.spots.find((s) => s.id === p.hidden);
    if (spot) { spot.occupant = null; p.sim.x = spot.exitX; p.sim.z = spot.exitZ; }
    p.hidden = null;
  }

  // ----- combat -----
  _startAttack(k) {
    if (this.tick < k.attackReady || k.windup > 0) return;
    k.windup = this.t.windup;
    k.attackReady = this.tick + this.t.cooldown;
    this._emit({ e: 'swing', id: k.id });
    if (k.windup === 0) this._resolveAttack(k);
  }
  _updateAttacks() {
    for (const k of this.players.values()) {
      if (k.role !== 'killer' || k.windup <= 0 || !this._inPlay(k)) continue;
      if (--k.windup === 0) this._resolveAttack(k);
    }
  }
  _resolveAttack(k) {
    const A = this.rules.attack;
    const [fx, fz] = this._forward(k);
    const cosLimit = Math.cos((A.halfAngleDeg * Math.PI) / 180);
    let target = null, bestD = Infinity;
    for (const v of this.players.values()) {
      if (v.role !== 'survivor' || !this._inPlay(v) || v.hidden) continue;
      const dx = v.sim.x - k.sim.x, dz = v.sim.z - k.sim.z, d = Math.hypot(dx, dz);
      if (d > A.range + this.rules.player.halfWidth + A.leniency) continue;
      if (d > 0.5 && (dx * fx + dz * fz) / d < cosLimit) continue;
      if (Math.abs(v.sim.y - k.sim.y) > A.vertical) continue;
      if (Sim.segmentBlocked(this.map, k.sim.x, k.sim.z, v.sim.x, v.sim.z, k.sim.y + 1.0)) continue; // no hits through walls
      if (d < bestD) { bestD = d; target = v; }
    }
    if (!target) return;
    k.stats.hitsLanded++;
    k.attackReady = Math.max(k.attackReady, this.tick + this.t.hitCooldown);
    this._damage(target, A.damage, k);
  }
  _damage(v, amount, attacker) {
    v.health = Math.max(0, v.health - amount);
    v.sim.haste = this.t.haste;
    this._stopWork(v);
    this._emit({ e: 'hit', v: v.id, a: attacker.id, h: v.health });
    if (v.health > 0) return;
    v.eliminated = true;
    this._freeSpot(v);
    this._emit({ e: 'elim', id: v.id });
    if (this.hooks.onEliminated) this.hooks.onEliminated(v.id);
  }

  // ----- exits -----
  _checkExits() {
    if (!this.exitsOpen) return;
    for (const p of this.players.values()) {
      if (p.role !== 'survivor' || !this._inPlay(p) || p.hidden) continue;
      for (const x of this.map.exits) {
        if (Math.abs(p.sim.x - x.x) <= x.hx && Math.abs(p.sim.z - x.z) <= x.hz) {
          p.escaped = true;
          this._stopWork(p);
          this._emit({ e: 'esc', id: p.id });
          if (this.hooks.onEscaped) this.hooks.onEscaped(p.id);
          break;
        }
      }
    }
  }

  // ---------- snapshots ----------
  _canSee(viewer, target) {
    if (target.hidden && (viewer.role === 'killer' || !this._inPlay(viewer))) return false; // never leak hidden survivors
    return true;
  }

  snapshotFor(id, events) {
    const me = this.players.get(id);
    if (!me) return null;
    const s = me.sim;
    const others = [];
    for (const p of this.players.values()) {
      if (p === me || !this._inPlay(p) || !this._canSee(me, p)) continue;
      const fl = (p.sim.crouch ? 1 : 0) | (p.sprinting ? 2 : 0) | (p.hidden ? 4 : 0) | (p.moving ? 8 : 0) | (p.windup > 0 ? 16 : 0);
      others.push([p.id, r3(p.sim.x), r3(p.sim.y), r3(p.sim.z), r3(p.sim.yaw), r3(p.sim.pitch), fl]);
    }
    return {
      t: 'snap',
      k: this.tick,
      ack: me.lastSeq,
      you: {
        x: r4(s.x), y: r4(s.y), z: r4(s.z), vy: r4(s.vy), g: s.onGround ? 1 : 0, cr: s.crouch ? 1 : 0,
        st: r4(s.stamina), ex: s.exhausted ? 1 : 0, rg: s.regen, hs: s.haste,
        h: me.health, hid: me.hidden, wk: me.working, el: me.eliminated ? 1 : 0, es: me.escaped ? 1 : 0,
        rdy: Math.max(0, me.attackReady - this.tick),
      },
      p: others,
      o: this.objectives.map((o) => [o.id, r3(o.progress / o.workSeconds), o.done ? 1 : 0]),
      ex: this.exitsOpen ? 1 : 0,
      ev: events || [],
    };
  }

  /** Test-only helper: place a player directly. Never reachable from the network. */
  _testPlace(id, { x, z, yaw = 0, y = 0 }) {
    const p = this.players.get(id);
    Object.assign(p.sim, { x, z, y, yaw, vy: 0, onGround: true });
  }
}

module.exports = { World, MAX_QUEUE };
