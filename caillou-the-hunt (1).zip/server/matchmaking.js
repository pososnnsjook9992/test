'use strict';

// Global queue. No rooms, no codes: players join one queue and the server groups them.
class Matchmaker {
  constructor(cfg) {
    this.cfg = cfg.match;
    this.queue = []; // { session, since }
  }
  has(session) { return this.queue.some((e) => e.session === session); }
  enqueue(session, now = Date.now()) {
    if (this.has(session)) return false;
    this.queue.push({ session, since: now });
    return true;
  }
  dequeue(session) {
    const i = this.queue.findIndex((e) => e.session === session);
    if (i < 0) return false;
    this.queue.splice(i, 1);
    return true;
  }
  // Full lobbies start immediately; a partial lobby (>= minPlayers) starts once the oldest
  // waiting player has waited fillWaitMs.
  formGroups(now = Date.now()) {
    const { minPlayers, maxPlayers, fillWaitMs } = this.cfg;
    const groups = [];
    while (this.queue.length >= maxPlayers) {
      groups.push(this.queue.splice(0, maxPlayers).map((e) => e.session));
    }
    if (this.queue.length >= minPlayers && now - this.queue[0].since >= fillWaitMs) {
      groups.push(this.queue.splice(0).map((e) => e.session));
    }
    return groups;
  }
  status() {
    return this.queue.map((e, i) => ({ session: e.session, position: i + 1, queued: this.queue.length }));
  }
}

module.exports = { Matchmaker };
