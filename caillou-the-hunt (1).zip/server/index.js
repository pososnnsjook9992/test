'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');
const { buildConfig } = require('./config');
const { parseMessage } = require('./protocol');
const { SessionStore } = require('./sessions');
const { Matchmaker } = require('./matchmaking');
const { Match } = require('./match');

const ROOT = path.resolve(__dirname, '..');
const PUBLIC_DIR = path.join(ROOT, 'public');
// Only these directories are ever served. /shared is the simulation code the browser shares with the server;
// /vendor/three exposes ONLY the built Three.js files from node_modules (installed with `npm install`).
const MOUNTS = [
  { prefix: '/shared/', dir: path.join(ROOT, 'shared') },
  { prefix: '/vendor/three/', dir: path.join(ROOT, 'node_modules', 'three', 'build') },
  { prefix: '/', dir: PUBLIC_DIR }
];
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.webp': 'image/webp', '.ogg': 'audio/ogg', '.mp3': 'audio/mpeg', '.wav': 'audio/wav'
};

function serveStatic(req, res) {
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405).end(); return; }
  if (req.url.split('?')[0] === '/healthz') { res.writeHead(200).end('ok'); return; }
  let rel;
  try { rel = decodeURIComponent(req.url.split('?')[0]); } catch { res.writeHead(400).end(); return; }
  if (rel === '/') rel = '/index.html';
  const mount = MOUNTS.find((m) => rel.startsWith(m.prefix));
  const baseDir = mount.dir;
  const file = path.resolve(baseDir, rel.slice(mount.prefix.length));
  if (file !== baseDir && !file.startsWith(baseDir + path.sep)) { res.writeHead(403).end(); return; } // path traversal guard
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404).end('not found'); return; }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff' });
    res.end(req.method === 'HEAD' ? undefined : data);
  });
}

function createServer(overrides = {}) {
  const cfg = buildConfig(overrides);
  const sessions = new SessionStore(cfg);
  const matchmaker = new Matchmaker(cfg);
  const matches = new Map();
  const intervals = [];

  const httpServer = http.createServer(serveStatic);
  const wss = new WebSocketServer({ server: httpServer, maxPayload: cfg.net.maxPayloadBytes });

  // ---- session state transitions ----
  function release(session) {
    session.state = 'lobby';
    session.matchId = null;
    session.send({ t: 'lobby' });
  }
  function enqueue(session) {
    session.state = 'queued';
    session.matchId = null;
    matchmaker.enqueue(session);
    pushQueueStatus();
  }
  function pushQueueStatus() {
    for (const s of matchmaker.status()) {
      s.session.send({ t: 'queued', position: s.position, queued: s.queued, minPlayers: cfg.match.minPlayers, maxPlayers: cfg.match.maxPlayers });
    }
  }

  const hooks = {
    releaseSession: release,
    onFinished(match, present) {
      matches.delete(match.id);
      present.forEach(release);
    },
    onAborted(match, present) {
      matches.delete(match.id);
      for (const s of present) {
        if (s.connected) enqueue(s); else release(s);
      }
    }
  };

  function formMatch(group) {
    const id = crypto.randomBytes(6).toString('hex');
    const match = new Match(id, cfg, group, hooks);
    matches.set(id, match);
    for (const s of group) { s.state = 'in_match'; s.matchId = id; }
    match.start();
  }

  // ---- connection handling ----
  function send(ws, msg) { if (ws.readyState === 1) ws.send(JSON.stringify(msg)); }

  function onDisconnect(session) {
    session.detach();
    if (matchmaker.dequeue(session)) session.state = 'lobby';
    if (session.state === 'in_match') {
      const m = matches.get(session.matchId);
      if (m) m.onDisconnect(session); else release(session);
    }
  }

  function handleHello(ws, msg) {
    let s = sessions.resume(msg.token);
    if (s) {
      if (s.ws && s.ws !== ws) { const old = s.ws; s.ws = null; old.close(4000, 'replaced by new connection'); }
    } else {
      s = sessions.create(msg.name);
    }
    s.attach(ws);
    send(ws, { t: 'welcome', token: s.token, name: s.name, state: s.state, serverTime: Date.now() });
    if (s.state === 'in_match') {
      const m = matches.get(s.matchId);
      if (!m || !m.onReconnect(s)) release(s);
    } else if (s.state === 'queued') {
      s.state = 'lobby'; // queue spots are not held across a dropped connection
      matchmaker.dequeue(s);
    }
    return s;
  }

  function handle(session, msg) {
    switch (msg.t) {
      case 'play':
        if (session.state !== 'lobby') return session.send({ t: 'error', error: 'invalid_state' });
        enqueue(session);
        break;
      case 'cancel_queue':
        if (session.state === 'queued') { matchmaker.dequeue(session); release(session); }
        break;
      case 'leave_match': {
        if (session.state !== 'in_match') break;
        const m = matches.get(session.matchId);
        if (m) m.onLeave(session); else release(session);
        break;
      }
      case 'ping':
        session.send({ t: 'pong', serverTime: Date.now() });
        break;
      case 'input': {
        if (session.state !== 'in_match') break;
        const m = matches.get(session.matchId);
        if (m) m.onInput(session, msg.cmds);
        break;
      }
    }
  }

  wss.on('connection', (ws) => {
    ws.isAlive = true;
    let session = null;
    let windowStart = Date.now();
    let count = 0;
    ws.on('pong', () => { ws.isAlive = true; });
    ws.on('message', (data, isBinary) => {
      const now = Date.now();
      if (now - windowStart >= 1000) { windowStart = now; count = 0; }
      if (++count > cfg.net.maxMsgsPerSec) { ws.close(1008, 'rate limit'); return; }
      const parsed = parseMessage(data, isBinary);
      if (!parsed.ok) { send(ws, { t: 'error', error: parsed.error }); return; }
      const msg = parsed.msg;
      if (msg.t === 'hello') {
        if (session) { send(ws, { t: 'error', error: 'already_authenticated' }); return; }
        session = handleHello(ws, msg);
        return;
      }
      if (!session) { send(ws, { t: 'error', error: 'hello_required' }); return; }
      handle(session, msg);
    });
    ws.on('close', () => {
      if (session && session.ws === ws) onDisconnect(session);
    });
    ws.on('error', () => {});
  });

  return {
    cfg, matches, sessions, matchmaker,
    get port() { return httpServer.address() && httpServer.address().port; },
    start() {
      return new Promise((resolve) => {
        httpServer.listen(cfg.port, () => {
          intervals.push(setInterval(() => { for (const g of matchmaker.formGroups()) formMatch(g); }, cfg.tickMs));
          intervals.push(setInterval(pushQueueStatus, cfg.queueStatusMs));
          intervals.push(setInterval(() => sessions.sweep(), cfg.sweepMs));
          intervals.push(setInterval(() => {
            for (const ws of wss.clients) {
              if (!ws.isAlive) { ws.terminate(); continue; }
              ws.isAlive = false;
              ws.ping();
            }
          }, cfg.net.heartbeatMs));
          resolve(this);
        });
      });
    },
    stop() {
      intervals.forEach(clearInterval);
      for (const m of matches.values()) m.dispose();
      for (const ws of wss.clients) ws.terminate();
      return new Promise((resolve) => wss.close(() => httpServer.close(() => resolve())));
    }
  };
}

module.exports = { createServer };

if (require.main === module) {
  createServer({ port: Number(process.env.PORT) || 3000 }).start().then((s) => {
    console.log(`CAILLOU: THE HUNT server listening on :${s.port}`);
  });
}
