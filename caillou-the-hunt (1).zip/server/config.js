'use strict';
const Sim = require('../shared/sim');
// All tunables live here so match size, timers and rules can change without touching logic.
const DEFAULTS = {
  port: 3000,
  tickMs: 500,            // matchmaking loop interval
  queueStatusMs: 2000,    // how often queued players get position updates
  sweepMs: 30000,         // stale-session cleanup interval
  sessionIdleTtlMs: 5 * 60 * 1000,
  match: {
    minPlayers: 2,        // smallest match the matchmaker will start (1 killer + 1 survivor)
    maxPlayers: 9,        // 1 killer + up to 8 survivors
    killerCount: 1,
    fillWaitMs: 10000,    // after minPlayers is reached, wait this long for more players
    countdownMs: 10000,   // pre-match countdown
    durationMs: 10 * 60 * 1000,
    resultsMs: 15000,     // post-match results screen
    reconnectGraceMs: 30000,
    minEscapesToWin: 1,   // survivors win once nobody is left in play if at least this many escaped
    maps: ['placeholder'] // real map IDs arrive with the Map Builder
  },
  net: {
    maxPayloadBytes: 4096,
    maxMsgsPerSec: 60,        // input arrives ~15 msgs/s per player; headroom for lobby traffic
    heartbeatMs: 10000
  }
};

function buildConfig(overrides = {}) {
  const cfg = {
    ...DEFAULTS,
    ...overrides,
    match: { ...DEFAULTS.match, ...(overrides.match || {}) },
    net: { ...DEFAULTS.net, ...(overrides.net || {}) },
    rules: Sim.mergeRules(overrides.rules) // movement / stamina / combat numbers; also sent to clients for prediction
  };
  const m = cfg.match;
  const problems = [];
  if (!(m.killerCount >= 1)) problems.push('match.killerCount must be >= 1');
  if (!(m.minPlayers >= m.killerCount + 1)) problems.push('match.minPlayers must be >= killerCount + 1');
  if (!(m.maxPlayers >= m.minPlayers)) problems.push('match.maxPlayers must be >= minPlayers');
  for (const k of ['fillWaitMs', 'countdownMs', 'durationMs', 'resultsMs', 'reconnectGraceMs']) {
    if (!(m[k] > 0)) problems.push(`match.${k} must be > 0`);
  }
  if (!Array.isArray(m.maps) || m.maps.length === 0) problems.push('match.maps must be a non-empty array');
  if (problems.length) throw new Error('Invalid config: ' + problems.join('; '));
  return cfg;
}

module.exports = { DEFAULTS, buildConfig };
