'use strict';
const crypto = require('crypto');
const Sim = require('../shared/sim');
const { World } = require('./world');
const { getMap } = require('./maps');

const STATE = { COUNTDOWN: 'countdown', ACTIVE: 'active', ENDED: 'ended', ABORTED: 'aborted' };

function secureShuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = crypto.randomInt(i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/**
 * One isolated match. It only ever talks to its own players, owns its own timers and
 * state, and holds the server-side truth about roles. Clients never choose roles.
 *
 * hooks: { releaseSession(session), onFinished(match, sessions), onAborted(match, sessions) }
 */
class Match {
  constructor(id, cfg, sessions, hooks) {
    this.id = id;
    this.cfg = cfg.match;
    this.hooks = hooks;
    this.state = STATE.COUNTDOWN;
    this.rules = cfg.rules;
    this.mapId = this.cfg.maps[crypto.randomInt(this.cfg.maps.length)];
    this.map = getMap(this.mapId);
    this.simTimer = null;
    this.players = new Map(); // session.id -> player
    this.timers = new Set();
    this.results = null;
    this.countdownEndsAt = null;
    this.endsAt = null;

    const killerIdx = new Set(secureShuffle([...sessions.keys()]).slice(0, this.cfg.killerCount));
    sessions.forEach((s, i) => {
      this.players.set(s.id, {
        id: crypto.randomBytes(4).toString('hex'), // public in-match id; never the session id
        session: s,
        name: s.name,
        role: killerIdx.has(i) ? 'killer' : 'survivor',
        status: 'connected',       // connected | disconnected | left
        reconnectDeadline: null,
        graceTimer: null,
        eliminated: false,
        escaped: false,
        spawn: null,
        outcome: null
      });
    });
    this._assignSpawns();
    this.world = new World({
      map: this.map,
      rules: this.rules,
      killerIds: this.state === STATE.ACTIVE ? [...this.players.values()].filter((x) => x.role === 'killer').map((x) => x.id) : undefined,
      players: [...this.players.values()].map((p) => ({ id: p.id, role: p.role, spawn: p.spawn })),
      hooks: { onEliminated: (id) => this.eliminate(id), onEscaped: (id) => this.escape(id) }
    });
  }

  // Server picks every spawn (random, distinct while spawns last, cycling if there are fewer spawns than players).
  _assignSpawns() {
    const pool = (list) => secureShuffle(list);
    const kSpawns = pool(this.map.killerSpawns), sSpawns = pool(this.map.survivorSpawns);
    let ki = 0, si = 0;
    for (const p of this.players.values()) {
      const src = p.role === 'killer' ? kSpawns : sSpawns;
      const i = p.role === 'killer' ? ki++ : si++;
      p.spawn = { ...src[i % src.length] };
    }
  }

  // ---------- helpers ----------
  _timer(fn, ms) {
    const t = setTimeout(() => { this.timers.delete(t); fn(); }, ms);
    this.timers.add(t);
    return t;
  }
  _clearTimers() {
    for (const t of this.timers) clearTimeout(t);
    this.timers.clear();
    for (const p of this.players.values()) { clearTimeout(p.graceTimer); p.graceTimer = null; }
    if (this.simTimer) { clearInterval(this.simTimer); this.simTimer = null; }
  }
  _present() { return [...this.players.values()].filter((p) => p.status !== 'left'); }
  _roster() {
    // Roles are deliberately NOT included. Each client learns only its own role until results.
    return [...this.players.values()].map((p) => ({ playerId: p.id, name: p.name, status: p.status }));
  }
  _broadcast(msg, exceptPlayer = null) {
    for (const p of this._present()) if (p !== exceptPlayer) p.session.send(msg);
  }
  snapshotFor(p) {
    return {
      matchId: this.id,
      state: this.state,
      mapId: this.mapId,
      map: this.map,
      rules: this.rules,
      you: { playerId: p.id, role: p.role, spawn: p.spawn, seq: this.world.seqOf(p.id) },
      roster: this._roster(),
      countdownEndsAt: this.countdownEndsAt,
      endsAt: this.endsAt,
      results: this.results,
      serverTime: Date.now()
    };
  }

  // ---------- lifecycle ----------
  start() {
    this.countdownEndsAt = Date.now() + this.cfg.countdownMs;
    for (const p of this.players.values()) p.session.send({ t: 'match_found', ...this.snapshotFor(p) });
    this._timer(() => this._beginActive(), this.cfg.countdownMs);
  }

  _beginActive() {
    if (this.state !== STATE.COUNTDOWN) return;
    this.state = STATE.ACTIVE;
    this.endsAt = Date.now() + this.cfg.durationMs;
    // From here on the killer is visible in the world, so their identity is no longer secret.
    const killerIds = [...this.players.values()].filter((p) => p.role === 'killer').map((p) => p.id);
    this._broadcast({ t: 'match_started', endsAt: this.endsAt, killerIds, serverTime: Date.now() });
    this._startSim();
    this._timer(() => this.end('survivors', 'time_expired'), this.cfg.durationMs);
  }

  // ---------- gameplay loop ----------
  _startSim() {
    this._dtMs = 1000 / this.rules.tickHz;
    this._acc = 0;
    this._last = performance.now();
    this._simTicks = 0;
    this.simTimer = setInterval(() => this._loop(), 8);
  }

  // Fixed-timestep loop: game time follows real time, but never runs more than 5 catch-up ticks at once.
  _loop() {
    if (this.state !== STATE.ACTIVE) return;
    const now = performance.now();
    this._acc += now - this._last;
    this._last = now;
    let n = 0;
    while (this._acc >= this._dtMs && this.state === STATE.ACTIVE) {
      if (n++ >= 5) { this._acc = 0; break; }
      this._acc -= this._dtMs;
      this._simTick();
    }
  }

  _simTick() {
    this.world.step();
    this._simTicks++;
    if (this.state !== STATE.ACTIVE || this._simTicks % this.rules.snapshotEvery !== 0) return;
    const events = this.world.flushEvents();
    for (const p of this._present()) if (p.status === 'connected') p.session.send(this.world.snapshotFor(p.id, events));
  }

  onInput(session, cmds) {
    const p = this.players.get(session.id);
    if (!p || p.status !== 'connected' || this.state !== STATE.ACTIVE) return;
    this.world.pushInput(p.id, cmds);
  }

  end(winner, reason) {
    if (this.state !== STATE.COUNTDOWN && this.state !== STATE.ACTIVE) return;
    this._clearTimers();
    this.state = STATE.ENDED;
    for (const p of this.players.values()) {
      if (p.status === 'left' && !p.eliminated && !p.escaped) p.outcome = 'forfeit';
      else p.outcome = (p.role === 'killer') === (winner === 'killer') ? 'win' : 'loss';
    }
    this.results = {
      winner,
      reason,
      players: [...this.players.values()].map((p) => ({
        playerId: p.id, name: p.name, role: p.role, outcome: p.outcome, eliminated: p.eliminated, escaped: p.escaped
      }))
    };
    this._broadcast({ t: 'match_ended', results: this.results, serverTime: Date.now() });
    this._timer(() => this._finish(), this.cfg.resultsMs);
  }

  _finish() {
    const sessions = this._present().map((p) => p.session);
    this.hooks.onFinished(this, sessions);
    this._clearTimers();
  }

  _abort(reason) {
    this._clearTimers();
    this.state = STATE.ABORTED;
    this._broadcast({ t: 'match_aborted', reason });
    this.hooks.onAborted(this, this._present().map((p) => p.session));
  }

  _destroyEmpty() {
    this._clearTimers();
    this.state = STATE.ENDED;
    this.hooks.onFinished(this, []);
  }

  dispose() { this._clearTimers(); }

  // Re-checks every end/abort rule. Called after anything that changes who is still present.
  _evaluate() {
    if (this.state !== STATE.COUNTDOWN && this.state !== STATE.ACTIVE) return;
    const present = this._present();
    if (present.length === 0) return this._destroyEmpty();
    const killers = present.filter((p) => p.role === 'killer');
    const survivors = present.filter((p) => p.role === 'survivor' && !p.eliminated && !p.escaped); // still in play
    if (this.state === STATE.COUNTDOWN) {
      if (killers.length === 0) return this._abort('killer_left_before_start');
      if (survivors.length === 0) return this._abort('survivors_left_before_start');
      return;
    }
    if (killers.length === 0) return this.end('survivors', 'killer_abandoned');
    if (survivors.length === 0) {
      const escaped = [...this.players.values()].filter((p) => p.escaped).length;
      if (escaped >= this.cfg.minEscapesToWin) return this.end('survivors', 'survivors_escaped');
      const anyEliminated = [...this.players.values()].some((p) => p.eliminated);
      return this.end('killer', anyEliminated ? 'all_survivors_eliminated' : 'survivors_abandoned');
    }
  }

  // ---------- player events ----------
  forfeit(p, reason) {
    if (p.status === 'left') return;
    clearTimeout(p.graceTimer);
    p.graceTimer = null;
    p.status = 'left';
    p.outcome = 'forfeit';
    this.world.removePlayer(p.id);
    this._broadcast({ t: 'player_status', playerId: p.id, status: 'left', reason });
    this.hooks.releaseSession(p.session);
    this._evaluate();
  }

  onLeave(session) {
    const p = this.players.get(session.id);
    if (p) this.forfeit(p, 'left');
  }

  onDisconnect(session) {
    const p = this.players.get(session.id);
    if (!p || p.status === 'left' || p.status === 'disconnected') return;
    if (this.state === STATE.ENDED || this.state === STATE.ABORTED) { p.status = 'disconnected'; return; }
    p.status = 'disconnected';
    p.reconnectDeadline = Date.now() + this.cfg.reconnectGraceMs;
    p.graceTimer = setTimeout(() => this.forfeit(p, 'disconnect_timeout'), this.cfg.reconnectGraceMs);
    this._broadcast({ t: 'player_status', playerId: p.id, status: 'disconnected', reconnectDeadline: p.reconnectDeadline }, p);
  }

  // Returns false if the player can no longer rejoin (caller sends them back to the lobby).
  onReconnect(session) {
    const p = this.players.get(session.id);
    if (!p || p.status === 'left') return false;
    if (this.state === STATE.ABORTED) return false;
    clearTimeout(p.graceTimer);
    p.graceTimer = null;
    p.reconnectDeadline = null;
    if (p.status === 'disconnected') {
      p.status = 'connected';
      this._broadcast({ t: 'player_status', playerId: p.id, status: 'connected' }, p);
    }
    this.world.resetInput(p.id);
    session.send({ t: 'match_resync', ...this.snapshotFor(p) });
    return true;
  }

  // Hook for Phase 2: the combat system will call this when the killer's damage kills a survivor.
  // Not reachable from any client message.
  eliminate(playerId) {
    if (this.state !== STATE.ACTIVE) return false;
    const p = [...this.players.values()].find((x) => x.id === playerId);
    if (!p || p.role !== 'survivor' || p.eliminated || p.status === 'left') return false;
    p.eliminated = true;
    this.world.markOut(p.id, 'eliminated');
    this._broadcast({ t: 'player_status', playerId: p.id, status: 'eliminated' });
    this._evaluate();
    return true;
  }

  // Called by the world when a survivor reaches an open exit. Not reachable from any client message.
  escape(playerId) {
    if (this.state !== STATE.ACTIVE) return false;
    const p = [...this.players.values()].find((x) => x.id === playerId);
    if (!p || p.role !== 'survivor' || p.escaped || p.eliminated || p.status === 'left') return false;
    p.escaped = true;
    this.world.markOut(p.id, 'escaped');
    this._broadcast({ t: 'player_status', playerId: p.id, status: 'escaped' });
    this._evaluate();
    return true;
  }
}

module.exports = { Match, STATE, secureShuffle };
