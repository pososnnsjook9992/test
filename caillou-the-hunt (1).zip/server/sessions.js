'use strict';
const crypto = require('crypto');
const { sanitizeName } = require('./protocol');

// A Session is the server's identity for one player. The secret token (kept by the client)
// is what lets a dropped connection resume the same session and the same match.
class Session {
  constructor(id, token, name) {
    this.id = id;
    this.token = token;
    this.name = name;
    this.ws = null;
    this.connected = false;
    this.state = 'lobby';     // 'lobby' | 'queued' | 'in_match'
    this.matchId = null;
    this.lastSeen = Date.now();
  }
  attach(ws) { this.ws = ws; this.connected = true; this.lastSeen = Date.now(); }
  detach() { this.ws = null; this.connected = false; this.lastSeen = Date.now(); }
  send(msg) { if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify(msg)); }
}

class SessionStore {
  constructor(cfg) {
    this.cfg = cfg;
    this.byToken = new Map();
  }
  create(name) {
    const id = crypto.randomUUID();
    const token = crypto.randomBytes(24).toString('hex');
    const s = new Session(id, token, sanitizeName(name) || `Player${crypto.randomInt(1000, 10000)}`);
    this.byToken.set(token, s);
    return s;
  }
  resume(token) { return token ? this.byToken.get(token) || null : null; }
  sweep(now = Date.now()) {
    for (const [token, s] of this.byToken) {
      if (!s.connected && s.state === 'lobby' && now - s.lastSeen > this.cfg.sessionIdleTtlMs) {
        this.byToken.delete(token);
      }
    }
  }
}

module.exports = { Session, SessionStore };
