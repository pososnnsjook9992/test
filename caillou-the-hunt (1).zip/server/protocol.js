'use strict';
// Every inbound client message passes through here. Only whitelisted fields survive,
// so a client can never smuggle a "role", "matchId" or similar into server logic.
const ALLOWED = new Set(['hello', 'play', 'cancel_queue', 'leave_match', 'ping', 'input']);
const TOKEN_RE = /^[a-f0-9]{48}$/;

function sanitizeName(v) {
  if (typeof v !== 'string') return null;
  const s = v.replace(/[\u0000-\u001f\u007f<>]/g, '').trim().slice(0, 20);
  return s.length ? s : null;
}

const fail = (error) => ({ ok: false, error });

// One input command = one simulation tick. Every field is validated; nothing positional or
// outcome-related (position, damage, role, ids) can be expressed here.
const AXIS = new Set([-1, 0, 1]);
function parseInput(o) {
  if (!Array.isArray(o.c) || o.c.length === 0 || o.c.length > 6) return fail('bad_input');
  const cmds = [];
  for (const c of o.c) {
    if (!c || typeof c !== 'object') return fail('bad_input');
    const { s, x, z, y, p, f } = c;
    if (!Number.isSafeInteger(s) || s < 1) return fail('bad_input');
    if (!AXIS.has(x) || !AXIS.has(z)) return fail('bad_input');
    if (typeof y !== 'number' || !Number.isFinite(y) || Math.abs(y) > 1e4) return fail('bad_input');
    if (typeof p !== 'number' || !Number.isFinite(p)) return fail('bad_input');
    if (!Number.isInteger(f) || f < 0 || f > 63) return fail('bad_input');
    cmds.push({ s, x, z, y, p: Math.max(-1.55, Math.min(1.55, p)), f });
  }
  return { ok: true, msg: { t: 'input', cmds } };
}

function parseMessage(raw, isBinary) {
  if (isBinary) return fail('binary_not_supported');
  let o;
  try { o = JSON.parse(raw.toString()); } catch { return fail('bad_json'); }
  if (!o || typeof o !== 'object' || Array.isArray(o) || typeof o.t !== 'string') return fail('bad_message');
  if (!ALLOWED.has(o.t)) return fail('unknown_type');
  if (o.t === 'hello') {
    return {
      ok: true,
      msg: {
        t: 'hello',
        token: typeof o.token === 'string' && TOKEN_RE.test(o.token) ? o.token : null,
        name: sanitizeName(o.name)
      }
    };
  }
  if (o.t === 'input') return parseInput(o);
  return { ok: true, msg: { t: o.t } };
}

module.exports = { parseMessage, sanitizeName };
