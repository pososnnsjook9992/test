'use strict';
// "Placeholder Yard": an 80x80 arena with a central house, four sheds, crates and lockers.
// Real maps will be authored in the Phase 7 Map Builder and stored in the database; they must
// match this shape, which is also what the client renders and what the server collides against.

const box = (x, z, w, d, h, kind = 'wall', y = 0) => ({ kind, min: [x - w / 2, y, z - d / 2], max: [x + w / 2, y + h, z + d / 2] });
const wallX = (x1, x2, z, h = 3.2, t = 0.4) => box((x1 + x2) / 2, z, x2 - x1, t, h); // wall running along x
const wallZ = (z1, z2, x, h = 3.2, t = 0.4) => box(x, (z1 + z2) / 2, t, z2 - z1, h); // wall running along z

const colliders = [];
const add = (...b) => colliders.push(...b);

// Perimeter (visible walls; movement is also clamped to bounds)
add(wallX(-40.5, 40.5, -40.5, 4, 1), wallX(-40.5, 40.5, 40.5, 4, 1), wallZ(-40.5, 40.5, -40.5, 4, 1), wallZ(-40.5, 40.5, 40.5, 4, 1));
// ...except the exit gates, which are carved out below by leaving the perimeter short; keep them simple:
colliders.length = 0;
add(wallX(-40.5, -5, -40.5, 4, 1), wallX(5, 40.5, -40.5, 4, 1), wallX(-40.5, -5, 40.5, 4, 1), wallX(5, 40.5, 40.5, 4, 1));
add(wallZ(-40.5, 40.5, -40.5, 4, 1), wallZ(-40.5, 40.5, 40.5, 4, 1));

// Central house 20x16 with 2.4m doorways on every side
add(wallX(-10, -1.2, -8), wallX(1.2, 10, -8), wallX(-10, -1.2, 8), wallX(1.2, 10, 8));
add(wallZ(-8, -1.2, -10), wallZ(1.2, 8, -10), wallZ(-8, -1.2, 10), wallZ(1.2, 8, 10));
add(wallZ(-8, -2.5, 0, 3.2, 0.3), wallZ(2.5, 8, 0, 3.2, 0.3)); // interior partition with a gap
add(box(5, -4, 2, 1, 0.8, 'crate'), box(-6, 4, 1.2, 1.2, 0.8, 'crate'), box(6, 5, 1.2, 1.2, 1.2, 'crate'));

// Four sheds 6x6, each with a doorway facing the house
for (const [sx, sz] of [[-28, -28], [28, -28], [-28, 28], [28, 28]]) {
  const x1 = sx - 3, x2 = sx + 3, z1 = sz - 3, z2 = sz + 3;
  const toward = sz < 0 ? 1 : -1; // door faces toward z = 0
  const doorZ = toward === 1 ? z2 : z1;
  const farZ = toward === 1 ? z1 : z2;
  add(wallX(x1, sx - 1.2, doorZ, 3, 0.3), wallX(sx + 1.2, x2, doorZ, 3, 0.3), wallX(x1, x2, farZ, 3, 0.3));
  add(wallZ(z1, z2, x1, 3, 0.3), wallZ(z1, z2, x2, 3, 0.3));
}

// Cover scattered around the yard: 0.8m crates can be jumped, 1.4m+ cannot
add(
  box(-16, -14, 1.2, 1.2, 0.8, 'crate'), box(16, -14, 1.2, 1.2, 0.8, 'crate'), box(-16, 14, 1.2, 1.2, 0.8, 'crate'), box(16, 14, 1.2, 1.2, 0.8, 'crate'),
  box(-20, 0, 2.5, 1.2, 1.6, 'crate'), box(20, 0, 2.5, 1.2, 1.6, 'crate'), box(0, -20, 1.2, 2.5, 1.6, 'crate'), box(0, 20, 1.2, 2.5, 1.6, 'crate'),
  box(-12, -30, 4, 0.6, 1.4, 'crate'), box(12, 30, 4, 0.6, 1.4, 'crate'), box(34, 6, 0.6, 5, 1.4, 'crate'), box(-34, -6, 0.6, 5, 1.4, 'crate'),
);

const ring = (n, r) => Array.from({ length: n }, (_, i) => {
  const a = (i / n) * Math.PI * 2;
  return { x: Math.round(Math.cos(a) * r * 100) / 100, y: 0, z: Math.round(Math.sin(a) * r * 100) / 100, yaw: Math.round((a + Math.PI / 2) * 100) / 100 };
});

module.exports = {
  id: 'placeholder',
  name: 'Placeholder Yard',
  version: 1,
  bounds: { min: [-40, -40], max: [40, 40] },
  colliders,
  killerSpawns: [{ x: 6, y: 0, z: 0, yaw: Math.PI / 2 }, { x: -6, y: 0, z: -1, yaw: -Math.PI / 2 }],
  survivorSpawns: ring(12, 30),
  // Objectives and hiding spots also get collider boxes (added by the registry).
  objectives: [
    { id: 'o_house', x: -6, z: -4, workSeconds: 25 },
    { id: 'o_nw', x: -28, z: -30.4, workSeconds: 25 },
    { id: 'o_ne', x: 28, z: -30.4, workSeconds: 25 },
    { id: 'o_sw', x: -28, z: 30.4, workSeconds: 25 },
    { id: 'o_se', x: 28, z: 30.4, workSeconds: 25 },
  ],
  exitUnlock: 4, // objectives that must be finished before the exit gates open
  hidingSpots: [
    { id: 'h_house_n', x: 8.5, z: -6.5, exitX: 8.5, exitZ: -5.0, yaw: 0 },
    { id: 'h_house_s', x: -8.5, z: 6.5, exitX: -8.5, exitZ: 5.0, yaw: Math.PI },
    { id: 'h_yard_w', x: -22, z: -8, exitX: -20.5, exitZ: -8, yaw: Math.PI / 2 },
    { id: 'h_yard_e', x: 22, z: 8, exitX: 20.5, exitZ: 8, yaw: -Math.PI / 2 },
  ],
  exits: [
    { id: 'x_north', x: 0, z: -38.5, hx: 4, hz: 1.5 },
    { id: 'x_south', x: 0, z: 38.5, hx: 4, hz: 1.5 },
  ],
  lighting: { fog: 0x05060a, fogDensity: 0.035, ambient: 0x2a3140 },
};
