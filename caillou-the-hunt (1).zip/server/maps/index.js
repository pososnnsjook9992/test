'use strict';
const Sim = require('../../shared/sim');

const RAW = [require('./placeholder')];

function deepFreeze(o) {
  if (o && typeof o === 'object' && !Object.isFrozen(o)) { Object.freeze(o); Object.values(o).forEach(deepFreeze); }
  return o;
}

/** Adds the collider boxes for objectives and hiding spots, so geometry and gameplay can never disagree. */
function finalize(raw) {
  const map = JSON.parse(JSON.stringify(raw));
  map.colliders = map.colliders.map((c, i) => ({ ...c, id: `c${i}` }));
  for (const o of map.objectives) {
    o.y = 0;
    map.colliders.push({ id: `c_${o.id}`, ref: o.id, kind: 'objective', min: [o.x - 0.6, 0, o.z - 0.6], max: [o.x + 0.6, 1.2, o.z + 0.6] });
  }
  for (const h of map.hidingSpots) {
    h.y = 0;
    map.colliders.push({ id: `c_${h.id}`, ref: h.id, kind: 'locker', min: [h.x - 0.5, 0, h.z - 0.5], max: [h.x + 0.5, 2, h.z + 0.5] });
  }
  return map;
}

/** Throws a descriptive error if a map cannot be played. Run on load and by tests. */
function validateMap(map, rules, limits = { killers: 1, survivors: 8 }) {
  const errs = [];
  const P = rules.player;
  const inBounds = (x, z) => x >= map.bounds.min[0] + P.halfWidth && x <= map.bounds.max[0] - P.halfWidth && z >= map.bounds.min[1] + P.halfWidth && z <= map.bounds.max[1] - P.halfWidth;
  const blocked = (x, z) => Sim.anyOverlap(map, x, 0, z, P.halfWidth, P.heightStand);
  const check = (label, x, z) => {
    if (!Number.isFinite(x) || !Number.isFinite(z)) errs.push(`${label} has non-numeric coordinates`);
    else if (!inBounds(x, z)) errs.push(`${label} is outside the map bounds`);
    else if (blocked(x, z)) errs.push(`${label} is inside a collider`);
  };
  map.killerSpawns.forEach((s, i) => check(`killerSpawns[${i}]`, s.x, s.z));
  map.survivorSpawns.forEach((s, i) => check(`survivorSpawns[${i}]`, s.x, s.z));
  map.hidingSpots.forEach((h) => check(`hidingSpot ${h.id} exit`, h.exitX, h.exitZ));
  if (map.killerSpawns.length < limits.killers) errs.push('not enough killer spawns');
  if (map.survivorSpawns.length < limits.survivors) errs.push('not enough survivor spawns');
  if (map.objectives.length < map.exitUnlock) errs.push('exitUnlock exceeds the number of objectives');
  if (map.exits.length < 1) errs.push('map needs at least one exit');
  const ids = new Set();
  for (const e of [...map.objectives, ...map.hidingSpots, ...map.exits]) {
    if (ids.has(e.id)) errs.push(`duplicate id ${e.id}`);
    ids.add(e.id);
  }
  for (const e of map.exits) {
    if (e.x - e.hx < map.bounds.min[0] || e.x + e.hx > map.bounds.max[0] || e.z - e.hz < map.bounds.min[1] || e.z + e.hz > map.bounds.max[1]) errs.push(`exit ${e.id} is outside the bounds`);
    if (blocked(e.x, e.z)) errs.push(`exit ${e.id} is inside a collider`);
  }
  if (errs.length) throw new Error(`Map "${map.id}" is invalid:\n - ${errs.join('\n - ')}`);
}

const maps = new Map();
function loadAll(rules) {
  for (const raw of RAW) {
    const map = finalize(raw);
    validateMap(map, rules);
    maps.set(map.id, deepFreeze(map));
  }
}
loadAll(Sim.mergeRules({}));

function getMap(id) {
  const m = maps.get(id);
  if (!m) throw new Error(`Unknown map "${id}"`);
  return m;
}

module.exports = { getMap, finalize, validateMap, listMapIds: () => [...maps.keys()] };
