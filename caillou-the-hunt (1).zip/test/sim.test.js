'use strict';
const test = require('node:test');
const assert = require('node:assert');
const Sim = require('../shared/sim');
const { F } = Sim;
const { getMap, finalize, validateMap } = require('../server/maps');

const rules = Sim.mergeRules({});
const TEST_MAP = {
  bounds: { min: [-50, -50], max: [50, 50] },
  colliders: [
    { min: [-50, 0, -5.5], max: [50, 3, -5] },        // wall across z = -5
    { min: [-50, 0, -10.5], max: [50, 0.8, -10] },    // jumpable low box
    { min: [-50, 0, -15.5], max: [50, 1.4, -15] },    // box too tall to jump
    { min: [-2, 1.5, 20], max: [2, 2.5, 24] },        // low ceiling slab (crouch-only gap)
  ],
};
const EMPTY = { bounds: { min: [-500, -500], max: [500, 500] }, colliders: [] };
const cmd = (o = {}) => ({ x: 0, z: 0, y: 0, p: 0, f: 0, ...o });
const spawn = (x = 0, z = 0) => Sim.createPlayerState({ x, y: 0, z, yaw: 0 }, 'survivor', rules);
function run(state, n, c, map = TEST_MAP, role = 'survivor') { for (let i = 0; i < n; i++) Sim.stepPlayer(state, cmd(c), map, rules, role); return state; }
const dist = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);

test('walk < run < sprint, each matching its configured speed over one second', () => {
  const speeds = {};
  for (const [name, f, expected] of [['walk', F.WALK, rules.survivor.walk], ['run', 0, rules.survivor.run], ['sprint', F.SPRINT, rules.survivor.sprint], ['crouch', F.CROUCH, rules.survivor.crouch]]) {
    const s = run(spawn(0, 0), 30, { z: 1, f }, EMPTY);
    speeds[name] = dist(s, { x: 0, z: 0 });
    assert.ok(Math.abs(speeds[name] - expected) < 0.05, `${name}: ${speeds[name]} vs ${expected}`);
  }
  assert.ok(speeds.crouch < speeds.walk || speeds.crouch < speeds.run);
  assert.ok(speeds.walk < speeds.run && speeds.run < speeds.sprint);
});

test('forward is -z at yaw 0; strafing and diagonals are never faster than straight', () => {
  const fwd = run(spawn(), 30, { z: 1 }, EMPTY);
  assert.ok(fwd.z < -4 && Math.abs(fwd.x) < 1e-9);
  const diag = run(spawn(), 30, { z: 1, x: 1 }, EMPTY);
  assert.ok(dist(diag, { x: 0, z: 0 }) <= rules.survivor.run + 0.01);
  const back = run(spawn(), 30, { z: -1 }, EMPTY);
  assert.ok(back.z > 4);
});

test('sprinting drains stamina, exhaustion blocks sprint until recovery, then it works again', () => {
  const s = spawn();
  let n = 0;
  while (!s.exhausted && n < 400) { run(s, 1, { z: 1, f: F.SPRINT }, EMPTY); n++; }
  assert.ok(s.exhausted, 'should become exhausted');
  assert.ok(n / rules.tickHz > 3 && n / rules.tickHz < 6, `drained in ${n / rules.tickHz}s`);
  const before = { x: s.x, z: s.z };
  run(s, 30, { z: 1, f: F.SPRINT }, EMPTY);
  assert.ok(dist(s, before) < rules.survivor.run + 0.3, 'exhausted sprint must fall back to run speed');
  run(s, 200, {}, EMPTY); // rest
  assert.ok(!s.exhausted && s.stamina > rules.survivor.stamina.exhaustRecoverAt);
  const b2 = { x: s.x, z: s.z };
  run(s, 15, { z: 1, f: F.SPRINT }, EMPTY);
  assert.ok(dist(s, b2) > rules.survivor.run * 0.5 + 0.2, 'sprint available again');
});

test('killers are faster than survivors at run speed but cannot sprint', () => {
  const k = Sim.createPlayerState({ x: 0, z: 0 }, 'killer', rules);
  run(k, 30, { z: 1, f: F.SPRINT }, EMPTY, 'killer');
  assert.ok(Math.abs(dist(k, { x: 0, z: 0 }) - rules.killer.run) < 0.05);
  assert.ok(rules.killer.run > rules.survivor.run);
});

test('walls block movement; bounds clamp position', () => {
  const s = run(spawn(0, -2), 120, { z: 1 }); // walk north into wall at z=-5
  assert.ok(s.z > -5 + rules.player.halfWidth - 0.01, `stopped at wall, z=${s.z}`);
  const e = run(spawn(0, 0), 600, { x: 1 }, { bounds: TEST_MAP.bounds, colliders: [] });
  assert.ok(e.x <= 50 - rules.player.halfWidth + 1e-9);
});

test('low (0.8m) boxes can be jumped, tall (1.4m) ones cannot; gravity returns the player to the ground', () => {
  const lowS = spawn(0, -8);
  for (let i = 0; i < 40; i++) Sim.stepPlayer(lowS, cmd({ z: 1, f: F.JUMP | F.SPRINT }), TEST_MAP, rules, 'survivor');
  assert.ok(lowS.z < -10.6, `cleared the low box, z=${lowS.z}`);
  const tallS = spawn(0, -13);
  for (let i = 0; i < 40; i++) Sim.stepPlayer(tallS, cmd({ z: 1, f: F.JUMP | F.SPRINT }), TEST_MAP, rules, 'survivor');
  assert.ok(tallS.z > -15 + rules.player.halfWidth - 0.01, `blocked by tall box, z=${tallS.z}`);
  run(lowS, 60, {});
  assert.ok(lowS.onGround);
  const j = spawn(); run(j, 3, { f: F.JUMP });
  assert.ok(j.y > 0 && !j.onGround);
  run(j, 60, {});
  assert.ok(j.onGround && j.y === 0);
});

test('crouching lowers speed and a player cannot stand up under a low ceiling', () => {
  const s = spawn(0, 19);
  run(s, 1, { f: F.CROUCH });
  assert.ok(s.crouch);
  run(s, 40, { z: -1, f: F.CROUCH }); // crawl under the slab at z 20..24, ceiling at 1.5 (taller than 1.2 crouch, lower than 1.8 stand)
  assert.ok(s.z > 20, 'crouched through the gap');
  run(s, 2, { f: 0 });
  assert.ok(s.crouch, 'must stay crouched while headroom is blocked');
  const standing = spawn(0, 19); // same spot, never crouched: the slab must stop a standing player
  run(standing, 40, { z: -1 });
  assert.ok(standing.z < 20 - rules.player.halfWidth + 0.01, `standing player blocked by slab, z=${standing.z}`);
});

test('simulation is deterministic: identical inputs give identical state', () => {
  const inputs = Array.from({ length: 300 }, (_, i) => cmd({ x: (i % 7) - 3 > 0 ? 1 : 0, z: i % 5 === 0 ? 0 : 1, y: Math.sin(i / 20) * 3, f: i % 50 < 25 ? F.SPRINT : i % 11 === 0 ? F.JUMP : 0 }));
  const a = spawn(3, 3), b = spawn(3, 3);
  for (const c of inputs) { Sim.stepPlayer(a, c, TEST_MAP, rules, 'survivor'); Sim.stepPlayer(b, c, TEST_MAP, rules, 'survivor'); }
  assert.deepStrictEqual(a, b);
});

test('segmentBlocked sees walls but ignores the target\'s own collider', () => {
  assert.ok(Sim.segmentBlocked(TEST_MAP, 0, 0, 0, -9, 1));
  assert.ok(!Sim.segmentBlocked(TEST_MAP, 0, 0, 0, -4, 1));
  const m = { colliders: [{ ref: 'a', min: [-1, 0, -6], max: [1, 2, -4] }] };
  assert.ok(Sim.segmentBlocked(m, 0, 0, 0, -5, 1));
  assert.ok(!Sim.segmentBlocked(m, 0, 0, 0, -5, 1, 'a'));
});

test('rules overrides are validated', () => {
  assert.throws(() => Sim.mergeRules({ survivor: { run: -1 } }));
  assert.throws(() => Sim.mergeRules({ tickHz: 0 }));
  assert.strictEqual(Sim.mergeRules({ survivor: { run: 5 } }).survivor.run, 5);
  assert.strictEqual(Sim.mergeRules({}).survivor.sprint, rules.survivor.sprint);
});

test('the shipped map is valid, and map validation catches broken maps', () => {
  const m = getMap('placeholder');
  assert.ok(m.objectives.length >= m.exitUnlock && m.survivorSpawns.length >= 8);
  const raw = JSON.parse(JSON.stringify(m));
  raw.survivorSpawns[0] = { x: 0, y: 0, z: -8, yaw: 0 }; // inside a house wall
  assert.throws(() => validateMap(finalize({ ...raw, colliders: raw.colliders.filter((c) => !c.ref).map(({ id, ...c }) => c) }), rules), /inside a collider/);
  const raw2 = JSON.parse(JSON.stringify(m));
  raw2.exitUnlock = 99;
  assert.throws(() => validateMap(finalize({ ...raw2, colliders: raw2.colliders.filter((c) => !c.ref).map(({ id, ...c }) => c) }), rules), /exitUnlock/);
});
