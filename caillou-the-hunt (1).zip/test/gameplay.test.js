'use strict';
const test = require('node:test');
const assert = require('node:assert');
const Sim = require('../shared/sim');
const { F } = Sim;
const { startGame, sleep } = require('./helpers');

const rules = Sim.mergeRules({});
const dt = 1 / rules.tickHz;
const dist = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);

test('match_found carries map, rules and own spawn; roles stay hidden until the match is live', async () => {
  const g = await startGame(3);
  try {
    for (const c of g.clients) {
      assert.strictEqual(c.found.map.id, 'placeholder');
      assert.ok(c.found.map.colliders.length > 20);
      assert.deepStrictEqual(c.found.rules.tickHz, rules.tickHz);
      assert.ok(c.found.you.spawn && Number.isFinite(c.found.you.spawn.x));
      assert.ok(c.found.roster.every((r) => !('role' in r)), 'roster must not leak roles');
    }
    const started = await g.killer.waitFor('match_started');
    assert.deepStrictEqual(started.killerIds, [g.killer.pid]);
    const spawns = g.clients.map((c) => `${c.found.you.spawn.x},${c.found.you.spawn.z}`);
    assert.strictEqual(new Set(spawns).size, 3, 'spawns are distinct');
  } finally { await g.stop(); }
});

test('movement: server moves a survivor along the commanded direction, never faster than sprint', async () => {
  const g = await startGame(3);
  try {
    const s = g.survivors[0];
    const p = g.world.players.get(s.pid);
    g.world._testPlace(s.pid, { x: -5, z: 26, yaw: 0 });
    await s.nextSnap();
    const a = s.snap;
    await s.drive({ z: 1, f: F.SPRINT }, 30);
    await sleep(150);
    const b = s.snap;
    const moved = dist(a.you, b.you);
    const ticks = b.k - a.k;
    assert.ok(b.you.z < a.you.z - 3, `moved forward (-z): ${a.you.z} -> ${b.you.z}`);
    assert.ok(Math.abs(b.you.x - a.you.x) < 0.01);
    assert.ok(moved <= (ticks + 1) * dt * rules.survivor.sprint + 0.05, `moved ${moved} in ${ticks} ticks`);
    assert.ok(b.ack > 0 && b.ack <= s.seq, 'server acknowledges processed commands');
    assert.ok(b.you.st < rules.survivor.stamina.max, 'sprinting spent stamina server-side');
    assert.ok(p.sim.stamina < rules.survivor.stamina.max);
  } finally { await g.stop(); }
});

test('speed hack: flooding more commands than ticks cannot make a player move faster', async () => {
  const g = await startGame(3);
  try {
    const s = g.survivors[0];
    g.world._testPlace(s.pid, { x: -5, z: 34, yaw: 0 });
    await s.nextSnap();
    const a = s.snap;
    // 36 messages x 6 commands in well under a second (216 commands); the server may only consume one per tick.
    for (let i = 0; i < 36; i++) s.send({ t: 'input', c: Array.from({ length: 6 }, () => ({ s: ++s.seq, x: 0, z: 1, y: 0, p: 0, f: F.SPRINT })) });
    await sleep(600);
    const b = s.snap;
    const ticks = b.k - a.k;
    const moved = dist(a.you, b.you);
    assert.ok(moved <= ticks * dt * rules.survivor.sprint + 0.05, `moved ${moved.toFixed(2)}m in ${ticks} ticks (max ${(ticks * dt * rules.survivor.sprint).toFixed(2)})`);
    // replaying / duplicating sequence numbers gains nothing either
    const before = g.world.players.get(s.pid).lastSeq;
    s.send({ t: 'input', c: [{ s: 1, x: 0, z: 1, y: 0, p: 0, f: 0 }, { s: 1, x: 0, z: 1, y: 0, p: 0, f: 0 }] });
    await sleep(150);
    assert.ok(g.world.players.get(s.pid).lastSeq >= before);
    assert.strictEqual(g.world.players.get(s.pid).queue.length, 0, 'stale sequence numbers are dropped');
  } finally { await g.stop(); }
});

test('malformed input is rejected without dropping the connection', async () => {
  const g = await startGame(3);
  try {
    const s = g.survivors[0];
    const bad = [
      { t: 'input', c: [{ s: 1, x: 2, z: 0, y: 0, p: 0, f: 0 }] },
      { t: 'input', c: [{ s: 1, x: 0, z: 0, y: 'NaN', p: 0, f: 0 }] },
      { t: 'input', c: [{ s: 1, x: 0, z: 0, y: 1e9, p: 0, f: 0 }] },
      { t: 'input', c: [{ s: 1, x: 0, z: 0, y: 0, p: 0, f: 999 }] },
      { t: 'input', c: [{ s: -4, x: 0, z: 0, y: 0, p: 0, f: 0 }] },
      { t: 'input', c: [] },
      { t: 'input', c: Array.from({ length: 50 }, (_, i) => ({ s: i + 1, x: 0, z: 0, y: 0, p: 0, f: 0 })) },
      { t: 'input', x: 1e6, z: 1e6 }, // "teleport" attempt: no position fields exist
    ];
    for (const m of bad) { s.send(m); await sleep(20); }
    await sleep(100);
    assert.strictEqual(s.errors.filter((e) => e === 'bad_input').length, bad.length);
    assert.strictEqual(s.closeInfo, null, 'connection stays open');
    assert.ok(Math.abs(g.world.players.get(s.pid).sim.x) < 100);
  } finally { await g.stop(); }
});

test('input sent before the match goes live is ignored', async () => {
  const server = await require('../server').createServer({ port: 0, tickMs: 50, queueStatusMs: 100, match: { fillWaitMs: 150, countdownMs: 600, durationMs: 30000, resultsMs: 300 } }).start();
  const { Client } = require('./helpers');
  const cs = [];
  try {
    for (let i = 0; i < 3; i++) { const c = new Client(server.port); await c.connect(null, 'x' + i); cs.push(c); }
    cs.forEach((c) => c.send({ t: 'play' }));
    const found = await Promise.all(cs.map((c) => c.waitFor('match_found')));
    const match = server.matches.get(found[0].matchId);
    const c0 = cs[0];
    const spawn = found[0].you.spawn;
    for (let i = 0; i < 5; i++) { c0.send({ t: 'input', c: [{ s: i + 1, x: 0, z: 1, y: 0, p: 0, f: F.SPRINT }] }); await sleep(30); }
    const p = match.world.players.get(found[0].you.playerId);
    assert.strictEqual(p.sim.x, spawn.x); assert.strictEqual(p.sim.z, spawn.z);
    assert.strictEqual(p.maxSeq, 0, 'nothing was queued');
  } finally { cs.forEach((c) => c.ws.terminate()); await server.stop(); }
});

test('objectives: hold-to-work completes exactly once, stops on release, exits open at the threshold', async () => {
  const g = await startGame(3);
  try {
    const [s1] = g.survivors;
    const w = g.world;
    w.objectives.forEach((o) => { o.workSeconds = 1; });
    const o = w.objectives.find((x) => x.id === 'o_house'); // at (-6,-4), 1.2m box
    w._testPlace(s1.pid, { x: -6, z: -2, yaw: 0 }); // south of it, facing -z (toward it)
    await s1.nextSnap();
    await s1.drive({ f: F.INTERACT }, 8); // brief hold
    await s1.drive({ f: 0 }, 6);          // release: progress must stop
    const mid = o.progress;
    assert.ok(mid > 0 && mid < 1, `partial progress ${mid}`);
    await s1.drive({ f: 0 }, 6);
    assert.strictEqual(o.progress, mid, 'no progress without holding');
    assert.ok(!o.done);
    await s1.drive({ f: F.INTERACT }, 40);
    await sleep(120);
    assert.ok(o.done, 'completed');
    assert.strictEqual(w.completed, 1);
    assert.strictEqual(s1.events.filter((e) => e.e === 'obj' && e.id === 'o_house').length, 1, 'completion event once');
    assert.strictEqual(s1.snap.o.find((x) => x[0] === 'o_house')[2], 1);
    // pressing again on a finished objective does nothing and never double-counts
    await s1.drive({ f: F.INTERACT }, 10);
    assert.strictEqual(w.completed, 1);
    assert.strictEqual(w.players.get(s1.pid).stats.objectivesCompleted, 1);
    // finish enough objectives to open the exits
    for (const x of w.objectives) if (!x.done && w.completed < w.map.exitUnlock) w._complete(x);
    assert.ok(w.exitsOpen);
    await sleep(150);
    assert.strictEqual(s1.snap.ex, 1);
    assert.ok(s1.events.some((e) => e.e === 'exits'));
  } finally { await g.stop(); }
});

test('server validates reach and facing: no working from across the map or while looking away', async () => {
  const g = await startGame(3);
  try {
    const s = g.survivors[0];
    const w = g.world;
    w._testPlace(s.pid, { x: -6, z: 12, yaw: 0 }); // far from o_house
    await s.nextSnap();
    await s.drive({ f: F.INTERACT }, 10);
    assert.strictEqual(w.players.get(s.pid).working, null);
    w._testPlace(s.pid, { x: -6, z: -2, yaw: Math.PI }); // adjacent but facing away
    await s.drive({ y: Math.PI, f: 0 }, 2);
    await s.drive({ y: Math.PI, f: F.INTERACT }, 6);
    assert.strictEqual(w.players.get(s.pid).working, null, 'not facing the objective');
    w._testPlace(s.pid, { x: -6, z: -2, yaw: 0 });
    await s.drive({ f: 0 }, 2);
    await s.drive({ f: F.INTERACT }, 6);
    assert.strictEqual(w.players.get(s.pid).working, 'o_house');
  } finally { await g.stop(); }
});

test('combat: server-validated hits, cooldown, range, walls, and survivors cannot attack', async () => {
  const g = await startGame(3);
  try {
    const k = g.killer, [v, other] = g.survivors;
    const w = g.world;
    w._testPlace(other.pid, { x: 30, z: 30 });
    w._testPlace(k.pid, { x: 20, z: 20, yaw: 0 });
    // victim directly ahead (-z) at 1.5m
    w._testPlace(v.pid, { x: 20, z: 18.5 });
    await k.nextSnap();
    // survivors have no attack
    await v.drive({ f: F.ATTACK }, 4); await v.drive({ f: 0 }, 2);
    assert.strictEqual(w.players.get(k.pid).stats.hitsLanded, 0);
    assert.strictEqual(w.players.get(v.pid).health, rules.survivor.health);

    await k.drive({ f: F.ATTACK }, 2); await k.drive({ f: 0 }, 10);
    const pv = w.players.get(v.pid);
    assert.strictEqual(pv.health, rules.survivor.health - rules.attack.damage, 'one hit');
    assert.ok(v.events.some((e) => e.e === 'hit' && e.v === v.pid), 'hit event broadcast');
    assert.ok(pv.sim.haste > 0, 'hit haste granted');

    // immediate second swing is blocked by the cooldown
    w._testPlace(v.pid, { x: 20, z: 18.5 });
    await k.drive({ f: F.ATTACK }, 2); await k.drive({ f: 0 }, 8);
    assert.strictEqual(pv.health, rules.survivor.health - rules.attack.damage, 'cooldown prevents a second hit');

    // out of range
    w.players.get(k.pid).attackReady = 0;
    w._testPlace(v.pid, { x: 20, z: 14 });
    await k.drive({ f: F.ATTACK }, 2); await k.drive({ f: 0 }, 10);
    assert.strictEqual(pv.health, rules.survivor.health - rules.attack.damage, 'too far away');

    // behind the player (outside the cone)
    w.players.get(k.pid).attackReady = 0;
    w._testPlace(v.pid, { x: 20, z: 21.5 });
    await k.drive({ f: F.ATTACK }, 2); await k.drive({ f: 0 }, 10);
    assert.strictEqual(pv.health, rules.survivor.health - rules.attack.damage, 'target behind the killer');
  } finally { await g.stop(); }
});

test('combat: no hits through walls; three hits eliminate; all survivors eliminated -> killer wins', async () => {
  const g = await startGame(3);
  try {
    const k = g.killer, [v, other] = g.survivors;
    const w = g.world;
    // House north wall runs along z=-8 (x in -10..-1.2). Killer south of it, victim north of it, 1.6m apart.
    w._testPlace(k.pid, { x: -5, z: -7.5, yaw: 0 });
    w._testPlace(v.pid, { x: -5, z: -9.0 });
    w._testPlace(other.pid, { x: 30, z: 30 });
    await k.nextSnap();
    await k.drive({ f: F.ATTACK }, 2); await k.drive({ f: 0 }, 10);
    assert.strictEqual(w.players.get(v.pid).health, rules.survivor.health, 'wall blocks the attack');

    // open field: kill both survivors
    const kill = async (victim, x, z) => {
      for (let i = 0; i < 3; i++) {
        w.players.get(k.pid).attackReady = 0;
        w._testPlace(k.pid, { x, z, yaw: 0 });
        w._testPlace(victim.pid, { x, z: z - 1.5 });
        await k.drive({ f: F.ATTACK }, 2); await k.drive({ f: 0 }, 9);
      }
    };
    await kill(v, 20, 20);
    assert.ok(w.players.get(v.pid).eliminated);
    assert.ok(g.match.players.get(g.match.players.keys().next().value));
    await kill(other, -20, 20);
    const ended = await k.waitFor('match_ended');
    assert.strictEqual(ended.results.winner, 'killer');
    assert.strictEqual(ended.results.reason, 'all_survivors_eliminated');
    assert.ok(ended.results.players.every((p) => p.role === 'killer' || p.eliminated));
  } finally { await g.stop(); }
});

test('hiding: hidden survivors are invisible to the killer, can be searched out, and re-hide is locked out', async () => {
  const g = await startGame(3);
  try {
    const k = g.killer, [v, mate] = g.survivors;
    const w = g.world;
    w._testPlace(mate.pid, { x: 30, z: 30 });
    w._testPlace(v.pid, { x: -20.5, z: -8, yaw: Math.PI / 2 }); // east of locker h_yard_w (-22,-8), facing west
    w._testPlace(k.pid, { x: -10, z: 10, yaw: 0 });
    await v.nextSnap();
    await v.drive({ y: Math.PI / 2, f: F.INTERACT }, 2); await v.drive({ y: Math.PI / 2, f: 0 }, 4);
    assert.strictEqual(w.players.get(v.pid).hidden, 'h_yard_w');
    await k.nextSnap(); await mate.nextSnap();
    assert.ok(!k.snap.p.some((e) => e[0] === v.pid), 'killer snapshot must not contain the hidden survivor');
    const seenByMate = mate.snap.p.find((e) => e[0] === v.pid);
    assert.ok(seenByMate && (seenByMate[6] & 4), 'teammates see the hidden flag');
    // hidden survivors cannot be hit
    w._testPlace(k.pid, { x: -20.5, z: -9.2, yaw: Math.PI / 2 });
    await k.drive({ y: Math.PI / 2, f: F.ATTACK }, 2); await k.drive({ y: Math.PI / 2, f: 0 }, 10);
    assert.strictEqual(w.players.get(v.pid).health, rules.survivor.health);
    // killer searches the locker
    await k.drive({ y: Math.PI / 2, f: F.INTERACT }, 2); await k.drive({ y: Math.PI / 2, f: 0 }, 4);
    assert.strictEqual(w.players.get(v.pid).hidden, null, 'ejected');
    assert.ok(k.events.some((e) => e.e === 'eject'));
    await k.nextSnap();
    assert.ok(k.snap.p.some((e) => e[0] === v.pid), 'now visible to the killer');
    // lockout: cannot immediately hide again
    w._testPlace(v.pid, { x: -20.5, z: -8, yaw: Math.PI / 2 });
    await v.drive({ y: Math.PI / 2, f: F.INTERACT }, 2); await v.drive({ y: Math.PI / 2, f: 0 }, 4);
    assert.strictEqual(w.players.get(v.pid).hidden, null, 'lockout after being searched out');
    // the survivor can leave voluntarily after hiding elsewhere
  } finally { await g.stop(); }
});

test('escape: survivors reaching an open exit escape; closed exits do nothing; all escaped -> survivors win', async () => {
  const g = await startGame(3);
  try {
    const k = g.killer, [a, b] = g.survivors;
    const w = g.world;
    w._testPlace(k.pid, { x: 6, z: 0 });
    w._testPlace(a.pid, { x: 0, z: -38.5 });
    await a.nextSnap(); await a.drive({ z: 0 }, 2);
    assert.ok(!w.players.get(a.pid).escaped, 'exit is closed');
    for (const o of w.objectives) if (w.completed < w.map.exitUnlock) w._complete(o);
    await a.drive({ f: 0 }, 2);
    assert.ok(w.players.get(a.pid).escaped, 'escaped through the open exit');
    assert.ok(g.match.players.get([...g.match.players.keys()].find((id) => g.match.players.get(id).id === a.pid)).escaped);
    await k.nextSnap(); await k.nextSnap(); // a snapshot generated after the escape
    assert.ok(!k.snap.p.some((e) => e[0] === a.pid), 'escaped players leave the world');
    w._testPlace(b.pid, { x: 0, z: 38.5 });
    const ended = await k.waitFor('match_ended');
    assert.strictEqual(ended.results.winner, 'survivors');
    assert.strictEqual(ended.results.reason, 'survivors_escaped');
    assert.strictEqual(ended.results.players.filter((p) => p.escaped).length, 2);
  } finally { await g.stop(); }
});

test('isolation: snapshots only ever contain players of the recipient\'s own match', async () => {
  const g = await startGame(9, { match: { fillWaitMs: 150 } });
  try {
    const { Client } = require('./helpers');
    // second match
    const extra = [];
    for (let i = 0; i < 3; i++) { const c = new Client(g.server.port); await c.connect(null, 'e' + i); extra.push(c); }
    extra.forEach((c) => c.send({ t: 'play' }));
    const found = await Promise.all(extra.map((c) => c.waitFor('match_found')));
    await Promise.all(extra.map((c) => c.waitFor('match_started')));
    assert.notStrictEqual(found[0].matchId, g.found0);
    const ids1 = new Set(g.clients.map((c) => c.pid));
    const ids2 = new Set(extra.map((c, i) => found[i].you.playerId));
    for (const c of g.clients) { const s = await c.nextSnap(); assert.ok(s.p.every((e) => ids1.has(e[0])), 'no foreign players'); assert.ok(s.p.length <= 8); }
    for (const c of extra) { const s = await c.nextSnap(); assert.ok(s.p.every((e) => ids2.has(e[0]))); }
    assert.strictEqual(g.server.matches.size, 2);
    extra.forEach((c) => c.ws.terminate());
  } finally { await g.stop(); }
});

test('reconnect during a live match: resync carries map and the next input sequence number; play continues', async () => {
  const g = await startGame(3);
  try {
    const s = g.survivors[0];
    g.world._testPlace(s.pid, { x: -5, z: 26, yaw: 0 });
    await s.drive({ z: 1 }, 10);
    const seqBefore = s.seq;
    s.drop();
    await sleep(100);
    const { Client } = require('./helpers');
    const s2 = new Client(g.server.port);
    await s2.connect(s.token);
    const re = await s2.waitFor('match_resync');
    assert.ok(re.map.colliders.length > 20 && re.rules);
    assert.strictEqual(re.you.playerId, s.pid);
    assert.ok(re.you.seq >= 1 && re.you.seq <= seqBefore);
    s2.seq = re.you.seq;
    const before = g.world.players.get(s.pid).sim.z;
    await s2.drive({ z: 1 }, 20);
    await sleep(120);
    assert.ok(g.world.players.get(s.pid).sim.z < before - 1, 'continues moving after reconnect');
    s2.ws.terminate();
  } finally { await g.stop(); }
});
