'use strict';
const test = require('node:test');
const assert = require('node:assert');
const http = require('node:http');
const { createServer } = require('../server');

// Raw request so '..' segments are not normalised away by a client library.
const get = (port, path) => new Promise((resolve, reject) => {
  http.get({ host: '127.0.0.1', port, path }, (res) => { let b = ''; res.on('data', (d) => (b += d)); res.on('end', () => resolve({ status: res.statusCode, type: res.headers['content-type'], body: b })); }).on('error', reject);
});

test('static serving: shared sim + client are served; everything outside the mounts is not', async () => {
  const server = await createServer({ port: 0 }).start();
  try {
    const sim = await get(server.port, '/shared/sim.js');
    assert.strictEqual(sim.status, 200);
    assert.match(sim.type, /javascript/);
    assert.match(sim.body, /HuntSim/);
    assert.strictEqual((await get(server.port, '/js/game.js')).status, 200);
    assert.strictEqual((await get(server.port, '/')).status, 200);
    assert.strictEqual((await get(server.port, '/healthz')).body, 'ok');
    for (const bad of ['/shared/../server/index.js', '/shared/%2e%2e/server/config.js', '/../package.json', '/vendor/three/../../package.json', '/js/%2e%2e/%2e%2e/server/match.js', '/%2e%2e/%2e%2e/etc/passwd']) {
      const r = await get(server.port, bad);
      assert.ok(r.status === 403 || r.status === 404, `${bad} -> ${r.status}`);
      assert.ok(!/require\(|root:/.test(r.body), `${bad} leaked content`);
    }
    // server source, config and tests are not reachable through any mount
    for (const p of ['/server/index.js', '/test/gameplay.test.js', '/package.json', '/node_modules/ws/package.json']) assert.strictEqual((await get(server.port, p)).status, 404, p);
  } finally { await server.stop(); }
});
