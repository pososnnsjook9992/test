'use strict';
// Real-browser smoke test (headless Chromium via Playwright; `npm i -D playwright && npx playwright install chromium`).
// Runs with ?norender so it does not need WebGL/Three.js: it exercises the actual client code
// (network, input, prediction, reconciliation, HUD) against a real in-process server.
const assert = require('assert');
const { chromium } = require('playwright');
const { createServer } = require('../server');
const Sim = require('../shared/sim');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const server = await createServer({ port: 0, tickMs: 50, queueStatusMs: 200, match: { fillWaitMs: 400, countdownMs: 1200, durationMs: 60000, resultsMs: 500, reconnectGraceMs: 5000 } }).start();
  const browser = await chromium.launch();
  const errors = [];
  const pages = [];
  try {
    for (let i = 0; i < 2; i++) {
      const page = await (await browser.newContext()).newPage();
      page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
      page.on('console', (m) => { if (m.type() === 'error') errors.push(`console: ${m.text()}`); });
      await page.goto(`http://127.0.0.1:${server.port}/?norender`);
      await page.fill('#name', 'Tester' + i);
      pages.push(page);
    }
    await sleep(300);
    for (const p of pages) await p.click('#play');
    for (const p of pages) await p.waitForSelector('#game:not(.hidden)', { timeout: 8000 });
    for (const p of pages) await p.waitForFunction(() => window.__game && window.__game.live, null, { timeout: 8000 });

    const roles = await Promise.all(pages.map((p) => p.evaluate(() => window.__game.role)));
    assert.deepStrictEqual([...roles].sort(), ['killer', 'survivor']);
    const sPage = pages[roles.indexOf('survivor')], kPage = pages[roles.indexOf('killer')];
    const match = [...server.matches.values()][0];
    const sId = await sPage.evaluate(() => window.__game.myId);
    const world = match.world;
    console.log('ok  both pages in a live match; roles', roles.join('/'));

    // HUD differs by role
    assert.ok(await kPage.$eval('#hudBars', (el) => el.classList.contains('hidden')), 'killer has no stamina/health bars');
    assert.ok(!(await sPage.$eval('#hudBars', (el) => el.classList.contains('hidden'))));

    // Server teleports the survivor to open ground; the client must adopt it (reconciliation).
    world._testPlace(sId, { x: -5, z: 26, yaw: 0 });
    await sPage.evaluate(() => { window.__game.yaw = 0; }); // look toward -z (the client keeps its spawn yaw otherwise)
    await sleep(400);
    let c = await sPage.evaluate(() => ({ x: window.__game.state.x, z: window.__game.state.z }));
    assert.ok(Math.hypot(c.x + 5, c.z - 26) < 0.2, `client adopted authoritative position ${JSON.stringify(c)}`);

    // Hold W (run) for ~1s, then idle: predicted client state must converge to the server's.
    await sPage.keyboard.down('KeyW'); await sleep(1000); await sPage.keyboard.up('KeyW');
    await sleep(600);
    c = await sPage.evaluate(() => ({ x: window.__game.state.x, z: window.__game.state.z, pend: window.__game.pending.length }));
    const sv = world.players.get(sId).sim;
    assert.ok(sv.z < 26 - 3, `server moved the player: z=${sv.z}`);
    assert.ok(Math.hypot(c.x - sv.x, c.z - sv.z) < 0.05, `client ${c.x.toFixed(3)},${c.z.toFixed(3)} vs server ${sv.x.toFixed(3)},${sv.z.toFixed(3)}`);
    console.log(`ok  prediction matches server after 1s of running (moved ${(26 - sv.z).toFixed(2)}m, divergence < 5cm)`);

    // Sprint drains stamina on the HUD and server-side
    await sPage.keyboard.down('ShiftLeft'); await sPage.keyboard.down('KeyW'); await sleep(900);
    await sPage.keyboard.up('KeyW'); await sPage.keyboard.up('ShiftLeft'); await sleep(300);
    assert.ok(world.players.get(sId).sim.stamina < 100, 'sprinting spent stamina');

    // Killer sees the survivor (interpolated remote entity); survivor sees the killer.
    assert.ok((await kPage.evaluate(() => window.__game.remote.size)) >= 1, 'killer receives survivor snapshots');
    assert.ok((await sPage.evaluate(() => window.__game.remote.size)) >= 1, 'survivor receives killer snapshots');

    // Objective: prompt appears next to it, holding E completes it (work time shortened for the test).
    world.objectives.forEach((o) => { o.workSeconds = 0.8; });
    world._testPlace(sId, { x: -6, z: -2, yaw: 0 });
    await sPage.evaluate(() => { window.__game.yaw = 0; });
    await sleep(400);
    const prompt = await sPage.textContent('#hudPrompt');
    assert.ok(/Hold E/.test(prompt), `prompt was "${prompt}"`);
    await sPage.keyboard.down('KeyE'); await sleep(1500); await sPage.keyboard.up('KeyE'); await sleep(300);
    assert.ok(await sPage.evaluate(() => window.__game.objectives.get('o_house').done), 'objective completed from the browser');
    assert.ok(/1\/5/.test(await sPage.textContent('#hudObj')), 'HUD shows 1/5');
    console.log('ok  objective prompt, hold-E work and HUD progress');

    // Connection drop -> auto reconnect -> match_resync -> still in the same match
    const seqBefore = await sPage.evaluate(() => window.__game.seq);
    const session = [...server.sessions.byToken.values()].find((s) => s.matchId === match.id && match.players.get(s.id).id === sId);
    session.ws.terminate();
    const pl = match.players.get(session.id);
    const until = async (fn, ms, what) => { const t0 = Date.now(); while (!fn()) { if (Date.now() - t0 > ms) throw new Error('timeout: ' + what); await sleep(50); } };
    await until(() => pl.status === 'disconnected', 3000, 'server notices the dropped connection');
    await until(() => pl.status === 'connected', 8000, 'client auto-reconnects and the server restores the player');
    await sPage.waitForFunction(() => window.__game.running && window.__game.live, null, { timeout: 5000 });
    await sleep(300);
    await sPage.keyboard.down('KeyS'); await sleep(500); await sPage.keyboard.up('KeyS'); await sleep(400);
    const after = await sPage.evaluate(() => ({ z: window.__game.state.z }));
    assert.ok(Math.abs(after.z - world.players.get(sId).sim.z) < 0.05, 'prediction still in sync after reconnect');
    console.log('ok  reconnect resumed the live match and input is accepted again');

    // Leave match returns to the lobby
    await kPage.click('#btnLeave');
    await Promise.all(pages.map((p) => p.waitForSelector('#game.hidden', { state: 'attached', timeout: 8000 })));
    console.log('ok  leaving ends the match for everyone and returns to the lobby UI');

    assert.deepStrictEqual(errors, [], 'no browser errors');
    console.log('\nBrowser smoke test: all checks passed');
  } catch (err) {
    console.error('\nFAILED:', err.message);
    if (errors.length) console.error('browser errors:', errors);
    process.exitCode = 1;
  } finally {
    await browser.close();
    await server.stop();
  }
})();
