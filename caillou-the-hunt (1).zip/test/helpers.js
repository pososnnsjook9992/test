'use strict';
const WebSocket = require('ws');
const { createServer } = require('../server');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const FAST = { tickMs: 50, queueStatusMs: 100, match: { fillWaitMs: 150, countdownMs: 200, durationMs: 30000, resultsMs: 300, reconnectGraceMs: 800 } };

class Client {
  constructor(port) { this.port = port; this.msgs = []; this.waiters = []; this.seq = 0; this.snap = null; this.events = []; this.errors = []; }
  connect(token, name) {
    return new Promise((resolve, reject) => {
      this.closeInfo = null;
      this.ws = new WebSocket(`ws://127.0.0.1:${this.port}`);
      this.ws.on('open', () => this.ws.send(JSON.stringify({ t: 'hello', token, name })));
      this.ws.on('message', (d) => {
        const m = JSON.parse(d.toString());
        if (m.t === 'snap') { this.snap = m; this.events.push(...m.ev); }
        else if (m.t === 'error') this.errors.push(m.error);
        this.msgs.push(m);
        this.waiters = this.waiters.filter((w) => (w.type === m.t && w.pred(m)) ? (clearTimeout(w.to), w.res(m), false) : true);
        if (m.t === 'welcome') { this.token = m.token; resolve(m); }
      });
      this.ws.on('close', (code) => { this.closeInfo = { code }; });
      this.ws.on('error', reject);
    });
  }
  send(o) { this.ws.send(JSON.stringify(o)); }
  waitFor(type, pred = () => true, ms = 4000) {
    const hit = this.msgs.find((m) => m.t === type && pred(m));
    if (hit) return Promise.resolve(hit);
    return new Promise((res, rej) => {
      const w = { type, pred, res, to: setTimeout(() => rej(new Error(`timeout waiting for ${type}`)), ms) };
      this.waiters.push(w);
    });
  }
  /** Wait for the next snapshot that arrives after this call. */
  async nextSnap(ms = 2000) {
    const k = this.snap ? this.snap.k : -1;
    const start = Date.now();
    while (Date.now() - start < ms) { if (this.snap && this.snap.k > k) return this.snap; await sleep(10); }
    throw new Error('no snapshot');
  }
  /** Send `ticks` commands at the real tick rate (2 per message, like the real client). */
  async drive(c, ticks) {
    let sent = 0;
    while (sent < ticks) {
      const n = Math.min(2, ticks - sent);
      const cmds = [];
      for (let i = 0; i < n; i++) cmds.push({ s: ++this.seq, x: 0, z: 0, y: 0, p: 0, f: 0, ...c });
      this.send({ t: 'input', c: cmds });
      sent += n;
      await sleep(66);
    }
  }
  drop() { this.ws.terminate(); }
}

/**
 * Starts a server, connects `n` clients, queues them and waits for the match to go live.
 * Returns the clients with .role/.pid filled in and the server-side Match for white-box assertions.
 */
async function startGame(n, overrides = {}) {
  const server = await createServer({ port: 0, ...FAST, ...overrides, match: { ...FAST.match, ...(overrides.match || {}) } }).start();
  const clients = [];
  for (let i = 0; i < n; i++) { const c = new Client(server.port); await c.connect(null, 'p' + i); clients.push(c); }
  clients.forEach((c) => c.send({ t: 'play' }));
  const found = await Promise.all(clients.map((c) => c.waitFor('match_found')));
  clients.forEach((c, i) => { c.found = found[i]; c.role = found[i].you.role; c.pid = found[i].you.playerId; c.seq = found[i].you.seq; });
  await Promise.all(clients.map((c) => c.waitFor('match_started')));
  const match = server.matches.get(found[0].matchId);
  const killer = clients.find((c) => c.role === 'killer');
  const survivors = clients.filter((c) => c.role === 'survivor');
  const stop = async () => { clients.forEach((c) => { try { c.ws.terminate(); } catch {} }); await server.stop(); };
  return { server, clients, match, world: match.world, killer, survivors, stop };
}

module.exports = { Client, startGame, sleep, FAST };
