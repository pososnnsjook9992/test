'use strict';
// End-to-end Phase 1 tests: real server, real WebSocket clients, short timers.
const assert = require('assert');
const WebSocket = require('ws');
const { createServer } = require('../server');

const FAST = { tickMs: 50, queueStatusMs: 100, match: { fillWaitMs: 400, countdownMs: 300, durationMs: 1200, resultsMs: 400, reconnectGraceMs: 500 } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

class Client {
  constructor(port) { this.port = port; this.msgs = []; this.waiters = []; }
  connect(token, name) {
    return new Promise((resolve, reject) => {
      this.closeInfo = null;
      this.ws = new WebSocket(`ws://127.0.0.1:${this.port}`);
      this.ws.on('open', () => this.ws.send(JSON.stringify({ t: 'hello', token, name })));
      this.ws.on('message', (d) => {
        const m = JSON.parse(d.toString());
        this.msgs.push(m);
        this.waiters = this.waiters.filter((w) => (w.type === m.t && w.pred(m)) ? (clearTimeout(w.to), w.res(m), false) : true);
        if (m.t === 'welcome') { this.token = m.token; resolve(m); }
      });
      this.ws.on('close', (code) => { this.closeInfo = { code }; });
      this.ws.on('error', reject);
    });
  }
  send(o) { this.ws.send(JSON.stringify(o)); }
  clear() { this.msgs = []; }
  waitFor(type, pred = () => true, ms = 4000) {
    const hit = this.msgs.find((m) => m.t === type && pred(m));
    if (hit) return Promise.resolve(hit);
    return new Promise((res, rej) => {
      const w = { type, pred, res, to: setTimeout(() => rej(new Error(`timeout waiting for ${type}`)), ms) };
      this.waiters.push(w);
    });
  }
  drop() { this.ws.terminate(); }
}

async function withServer(overrides, fn) {
  const server = await createServer({ port: 0, ...FAST, ...overrides, match: { ...FAST.match, ...(overrides.match || {}) } }).start();
  const clients = [];
  const make = async (name) => { const c = new Client(server.port); await c.connect(null, name); clients.push(c); return c; };
  try { await fn(server, make, clients); }
  finally { clients.forEach((c) => { try { c.ws.terminate(); } catch {} }); await server.stop(); }
}

const tests = [];
const test = (name, fn) => tests.push({ name, fn });

test('20 players -> 3 isolated matches, exactly 1 killer each, client-sent role ignored', () =>
  withServer({}, async (server, make) => {
    const cs = [];
    for (let i = 0; i < 20; i++) cs.push(await make('p' + i));
    cs.forEach((c) => c.send({ t: 'play', role: 'killer', matchId: 'x' })); // forged fields must be ignored
    const found = await Promise.all(cs.map((c) => c.waitFor('match_found')));
    const byMatch = new Map();
    found.forEach((f) => { if (!byMatch.has(f.matchId)) byMatch.set(f.matchId, []); byMatch.get(f.matchId).push(f); });
    assert.deepStrictEqual([...byMatch.values()].map((g) => g.length).sort((a, b) => a - b), [2, 9, 9]);
    const allIds = new Set();
    for (const group of byMatch.values()) {
      assert.strictEqual(group.filter((f) => f.you.role === 'killer').length, 1);
      for (const f of group) {
        assert(f.roster.every((r) => !('role' in r)), 'roster must not leak roles');
        assert.strictEqual(f.roster.length, group.length);
      }
      for (const r of group[0].roster) { assert(!allIds.has(r.playerId), 'player ids must not repeat across matches'); allIds.add(r.playerId); }
    }
    assert.strictEqual(server.matches.size, 3);
  }));

test('survivor reconnects within grace and resumes same match/role', () =>
  withServer({}, async (server, make) => {
    const [a, b, c] = [await make('a'), await make('b'), await make('c')];
    [a, b, c].forEach((x) => x.send({ t: 'play' }));
    const found = await Promise.all([a, b, c].map((x) => x.waitFor('match_found')));
    const idx = found.findIndex((f) => f.you.role === 'survivor');
    const victim = [a, b, c][idx];
    const watcher = [a, b, c].find((x, i) => i !== idx);
    victim.drop();
    const st = await watcher.waitFor('player_status', (m) => m.status === 'disconnected');
    assert(st.reconnectDeadline > Date.now());
    const v2 = new Client(server.port);
    await v2.connect(victim.token);
    const re = await v2.waitFor('match_resync');
    assert.strictEqual(re.matchId, found[idx].matchId);
    assert.strictEqual(re.you.role, 'survivor');
    assert.strictEqual(re.you.playerId, found[idx].you.playerId);
    await watcher.waitFor('player_status', (m) => m.status === 'connected');
    victim.ws = v2.ws;
  }));

test('second connection with same token replaces the first', () =>
  withServer({}, async (server, make) => {
    const a = await make('a');
    const a2 = new Client(server.port);
    await a2.connect(a.token);
    await sleep(100);
    assert.strictEqual(a.closeInfo && a.closeInfo.code, 4000);
    assert.strictEqual(a2.token, a.token);
  }));

test('killer disconnect past grace -> survivors win (killer_abandoned)', () =>
  withServer({ match: { durationMs: 5000 } }, async (server, make) => {
    const cs = [await make('a'), await make('b'), await make('c')];
    cs.forEach((x) => x.send({ t: 'play' }));
    const found = await Promise.all(cs.map((x) => x.waitFor('match_found')));
    const k = found.findIndex((f) => f.you.role === 'killer');
    await cs[k].waitFor('match_started');
    cs[k].drop();
    const other = cs.find((x, i) => i !== k);
    const end = await other.waitFor('match_ended');
    assert.strictEqual(end.results.winner, 'survivors');
    assert.strictEqual(end.results.reason, 'killer_abandoned');
    assert(end.results.players.some((p) => p.role === 'killer' && p.outcome === 'forfeit'));
  }));

test('all survivors leave -> killer wins (survivors_abandoned)', () =>
  withServer({ match: { durationMs: 5000 } }, async (server, make) => {
    const cs = [await make('a'), await make('b'), await make('c')];
    cs.forEach((x) => x.send({ t: 'play' }));
    const found = await Promise.all(cs.map((x) => x.waitFor('match_found')));
    const k = found.findIndex((f) => f.you.role === 'killer');
    await cs[k].waitFor('match_started');
    cs.forEach((x, i) => { if (i !== k) x.send({ t: 'leave_match' }); });
    const end = await cs[k].waitFor('match_ended');
    assert.strictEqual(end.results.winner, 'killer');
    assert.strictEqual(end.results.reason, 'survivors_abandoned');
    await cs.find((x, i) => i !== k).waitFor('lobby'); // leaver is free to requeue immediately
  }));

test('timer expiry -> survivors win, then players return to lobby and can requeue', () =>
  withServer({}, async (server, make) => {
    const [a, b] = [await make('a'), await make('b')];
    [a, b].forEach((x) => x.send({ t: 'play' }));
    const end = await a.waitFor('match_ended', () => true, 5000);
    assert.strictEqual(end.results.winner, 'survivors');
    assert.strictEqual(end.results.reason, 'time_expired');
    await a.waitFor('lobby');
    await b.waitFor('lobby');
    assert.strictEqual(server.matches.size, 0);
    a.clear(); a.send({ t: 'play' });
    await a.waitFor('queued');
  }));

test('reconnect after match fully ended -> lobby, not a broken match', () =>
  withServer({}, async (server, make) => {
    const [a, b] = [await make('a'), await make('b')];
    [a, b].forEach((x) => x.send({ t: 'play' }));
    await a.waitFor('lobby', () => true, 5000);
    const tok = a.token;
    a.drop();
    await sleep(100);
    const a2 = new Client(server.port);
    const w = await a2.connect(tok);
    assert.strictEqual(w.state, 'lobby');
  }));

test('countdown abort: killer lost before start -> survivor requeued', () =>
  withServer({ match: { countdownMs: 2000 } }, async (server, make) => {
    const [a, b] = [await make('a'), await make('b')];
    [a, b].forEach((x) => x.send({ t: 'play' }));
    const found = await Promise.all([a, b].map((x) => x.waitFor('match_found')));
    const k = found.findIndex((f) => f.you.role === 'killer');
    const [killer, surv] = k === 0 ? [a, b] : [b, a];
    killer.drop();
    const ab = await surv.waitFor('match_aborted', () => true, 3000);
    assert.strictEqual(ab.reason, 'killer_left_before_start');
    surv.clear();
    await surv.waitFor('queued');
    assert.strictEqual(server.matches.size, 0);
  }));

test('eliminating every survivor ends the match with a killer win', () =>
  withServer({ match: { durationMs: 5000 } }, async (server, make) => {
    const cs = [await make('a'), await make('b'), await make('c')];
    cs.forEach((x) => x.send({ t: 'play' }));
    const found = await Promise.all(cs.map((x) => x.waitFor('match_found')));
    await cs[0].waitFor('match_started');
    const match = [...server.matches.values()][0];
    found.filter((f) => f.you.role === 'survivor').forEach((f) => assert(match.eliminate(f.you.playerId)));
    const end = await cs[0].waitFor('match_ended');
    assert.strictEqual(end.results.winner, 'killer');
    assert.strictEqual(end.results.reason, 'all_survivors_eliminated');
  }));

test('bad input is rejected without breaking the connection or session', () =>
  withServer({}, async (server, make) => {
    const a = await make('a');
    a.ws.send('not json');
    assert.strictEqual((await a.waitFor('error', (m) => m.error === 'bad_json')).error, 'bad_json');
    a.send({ t: 'give_me_killer' });
    await a.waitFor('error', (m) => m.error === 'unknown_type');
    const raw = new Client(server.port);
    raw.ws = new WebSocket(`ws://127.0.0.1:${server.port}`);
    raw.ws.on('message', (d) => raw.msgs.push(JSON.parse(d.toString())));
    await new Promise((r) => raw.ws.on('open', r));
    raw.ws.send(JSON.stringify({ t: 'play' }));
    await sleep(100);
    assert(raw.msgs.some((m) => m.error === 'hello_required'));
    // forged token creates a fresh session, never someone else's
    const forged = new Client(server.port);
    await forged.connect('a'.repeat(48));
    assert.notStrictEqual(forged.token, 'a'.repeat(48));
    // oversized frame closes that socket only
    a.ws.send('x'.repeat(10000));
    await sleep(150);
    assert.strictEqual(a.closeInfo && a.closeInfo.code, 1009);
    raw.ws.terminate();
  }));

(async () => {
  let failed = 0;
  for (const t of tests) {
    const t0 = Date.now();
    try { await t.fn(); console.log(`PASS  ${t.name} (${Date.now() - t0}ms)`); }
    catch (e) { failed++; console.log(`FAIL  ${t.name}\n      ${e.stack.split('\n').slice(0, 3).join('\n      ')}`); }
  }
  console.log(failed ? `\n${failed} of ${tests.length} failed` : `\nAll ${tests.length} tests passed`);
  process.exit(failed ? 1 : 0);
})();
