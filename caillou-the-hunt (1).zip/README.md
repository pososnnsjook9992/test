# CAILLOU: THE HUNT

## Status: Phase 1 (multiplayer foundation) + Phase 2 (core gameplay)

Phases 3-9 of the blueprint (character systems, Creator Studio, database/asset storage, proximity voice, polish)
are **not built yet**. See "Not built yet" and "Known limitations".

## Run

```
npm install        # ws (WebSockets) and three (3D rendering)
npm start          # http://localhost:3000   (PORT env var overrides)
npm test           # 26 automated tests: shared simulation, server gameplay over real WebSockets, static serving, Phase 1 lifecycle
npm run test:browser   # optional: real-browser smoke test (needs `npm i -D playwright && npx playwright install chromium`)
```

Open the page in several tabs (each tab is its own player) and press Play. A match starts when 9 players are queued,
or when 2+ players have waited 10 s. (For a quick solo look, open two tabs.)

### Controls
Click the game to capture the mouse (Esc releases it). WASD move - Shift sprint (stamina) - C crouch (hold) - Z walk (hold) -
Space jump - E interact (hold to repair) - Left click attack (killer) - Tab switch spectate target. Arrow keys also turn.

## What a match looks like now

1. Queue -> server groups players -> 1 killer + survivors (server picks roles and spawns).
2. 10 s countdown. Then the match is live; the killer's identity becomes visible (it is a visible monster).
3. Survivors **repair objectives** (hold E, 25 s each; 4 of 5 open the exits), **hide** in lockers, then **escape** through an open exit.
4. The killer **hunts**: basic attack (3 hits eliminate a survivor), or searches lockers to pull out hiders.
5. Match ends: all survivors out of play (killer wins unless >= 1 escaped), timer expiry (survivors win), or disconnect rules from Phase 1.

## Layout

```
shared/sim.js          movement/stamina/collision simulation; the SAME file runs on the server and in the browser (prediction)
server/index.js        HTTP static + WebSocket wiring (serves only public/, shared/, and Three.js's build/ dir)
server/config.js       all tunables (match size, timers, grace periods, rate limits, gameplay rules)
server/protocol.js     inbound whitelist; clients can only send input commands, never positions/roles/damage
server/sessions.js     identity + secret reconnect token
server/matchmaking.js  global queue
server/match.js        one isolated match: roles, spawns, lifecycle timers, win/forfeit rules, 30 Hz game loop
server/world.js        authoritative gameplay: input queue, movement, objectives, hiding, combat, exits, snapshots
server/maps/           map definitions + registry that validates every map at load
public/                client: lobby UI, game.js (input/prediction/HUD), renderer.js (Three.js)
test/                  *.test.js (npm test) and browser-smoke.js (optional)
```

## How the multiplayer gameplay works

- **Commands, not state.** Each client tick (30 Hz) produces one command `{seq, move axes, yaw, pitch, button flags}`. The server consumes
  **exactly one command per tick per player** from a bounded queue, so flooding commands or speeding up a client clock gains nothing
  (tested). Duplicate/out-of-order sequence numbers are dropped.
- **Server decides everything else:** position, stamina, health, interaction reach/facing/line-of-sight, objective progress (completes once),
  hiding, attack hits (range, cone, height, cooldown, line-of-sight so walls block hits), escapes, eliminations.
- **Prediction + reconciliation.** The client runs `shared/sim.js` locally for instant response, then rewinds to the server's state and replays
  unacknowledged commands on every snapshot (15 Hz). Browser test: client and server agree to < 5 cm after running.
- **Other players** are interpolated ~120 ms behind. Hidden survivors are **never sent to the killer** (or to eliminated spectators).
- **Roles stay private until the match is live;** `match_found` carries only your own role, the map, the rules, and your own spawn.

## What is verified, and what is not

Verified by automated tests: shared simulation (speeds, stamina/exhaustion, collision, jumps, crouch, determinism); speed-hack and malformed-input
rejection; objectives (once-only completion, reach/facing checks); combat rules (cooldown, range, cone, walls, survivors cannot attack);
hiding/searching; escape + win conditions; match isolation; reconnect mid-match; path-traversal protection; and (browser) the real client's
prediction, HUD, objective interaction, reconnection and leave flow.

**NOT verified: the 3D rendering.** Three.js could not be installed in the environment where this was built, so `public/js/renderer.js`
has only been executed against a stub `three` (catches typos/logic errors, not wrong API usage or visual problems) and has **never been
looked at in a real WebGL browser**. Expect to fix small visual/API issues on first run. If Three.js fails to load, the game still runs with the HUD
only and shows a message. Nothing was load-tested; timings were verified with short test timers.

## Known limitations (deliberate for this phase)

- No lag compensation: attacks are judged on server positions (plus 0.3 m leniency, `rules.attack.leniency`). Fine on a LAN, mushy at high ping.
- Only hidden survivors are withheld from snapshots; no distance-based interest management yet, so a modified client could still read other
  players' positions (Phase 9 security pass).
- A disconnected player's avatar stays in the world (and can be hit) for the 30 s reconnect grace.
- Eliminated survivors can spectate; there is no voice yet, so "ghosting" via voice isn't an issue until Phase 8.
- Placeholder capsule avatars, no animation, no sound, one placeholder map. Killer has only the basic attack (abilities arrive in Phases 5-6).
- Survivors are not yet assigned characters (Phase 3). No downed state, healing, items, doors or AI.
- State is in memory: a server restart drops the queue, matches and sessions. No accounts yet (anonymous session token per tab).
- Survivors see the killer's position all the time once live (it is a visible character), like Pillar Chase 2.

## Not built yet

Phase 3 character systems - Phase 4 Creator Studio foundation (admin auth, asset DB/storage, versioning) - Phase 5 character/ability editors
and Caillou's kit - Phase 6 rig/animation/kill/sound/image/VFX tools - Phase 7 map/objective/item/AI/UI/match-settings editors and publishing -
Phase 8 proximity voice (WebRTC + SFU) - Phase 9 polish and security testing.
