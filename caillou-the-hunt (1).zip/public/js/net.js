'use strict';
// Thin WebSocket wrapper: stores the session token (per tab) and auto-reconnects,
// which is what lets the server restore a dropped player into their match.
class Net {
  constructor() {
    this.handlers = {};
    this.retry = 0;
    this.serverOffset = 0; // serverTime - clientTime
    this.open();
  }
  on(type, fn) { (this.handlers[type] = this.handlers[type] || []).push(fn); }
  emit(type, msg) { (this.handlers[type] || []).forEach((f) => f(msg)); }
  open() {
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    this.ws = new WebSocket(`${proto}://${location.host}`);
    this.ws.onopen = () => {
      this.retry = 0;
      this.ws.send(JSON.stringify({ t: 'hello', token: sessionStorage.getItem('hunt.token'), name: sessionStorage.getItem('hunt.name') }));
      this.emit('_open', {});
    };
    this.ws.onmessage = (e) => {
      const m = JSON.parse(e.data);
      if (m.serverTime) this.serverOffset = m.serverTime - Date.now();
      if (m.t === 'welcome') sessionStorage.setItem('hunt.token', m.token);
      this.emit(m.t, m);
    };
    this.ws.onclose = () => {
      this.emit('_close', {});
      setTimeout(() => this.open(), Math.min(5000, 500 * 2 ** this.retry++));
    };
  }
  send(o) { if (this.ws.readyState === 1) this.ws.send(JSON.stringify(o)); }
  serverNow() { return Date.now() + this.serverOffset; }
}
