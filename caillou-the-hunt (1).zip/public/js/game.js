'use strict';
// In-match client: input capture, client-side prediction + server reconciliation,
// snapshot interpolation for other players, HUD. 3D drawing lives in renderer.js and is optional:
// if Three.js is not installed the game still runs (HUD only), which also keeps this logic testable headless.
(function () {
  const Sim = window.HuntSim;
  const F = Sim.F;
  const $ = (id) => document.getElementById(id);
  const INTERP_MS = 120;
  const TURN_RATE = 2.2; // rad/s for arrow keys
  const MOUSE_SENS = 0.0022;

  class Game {
    constructor(net) {
      this.net = net;
      this.running = false;
      this.keys = new Set();
      this.latch = { jump: false, interact: false, attack: false };
      this.mouseDown = false;
      this.renderer = null;
      this.names = new Map();
      this._bindInput();
      setInterval(() => this._loop(), 8);
    }

    // ---------- lifecycle ----------
    async start(m) {
      this.stop(true);
      this.map = m.map;
      this.rules = m.rules;
      this.myId = m.you.playerId;
      this.role = m.you.role;
      this.seq = m.you.seq || 0;
      this.state = Sim.createPlayerState(m.you.spawn, this.role, this.rules);
      this.prev = { x: this.state.x, y: this.state.y, z: this.state.z };
      this.yaw = m.you.spawn.yaw || 0;
      this.pitch = 0;
      this.pending = [];
      this.outbox = [];
      this.remote = new Map();
      this.objectives = new Map(this.map.objectives.map((o) => [o.id, { progress: 0, done: false }]));
      this.exitsOpen = false;
      this.auth = { h: this.rules.survivor.health, hid: null, wk: null, el: 0, es: 0, rdy: 0, st: this.state.stamina };
      this.killerIds = new Set(m.killerIds || []);
      this.names = new Map((m.roster || []).map((r) => [r.playerId, r.name]));
      this.countdownEndsAt = m.countdownEndsAt;
      this.endsAt = m.endsAt;
      this.live = m.state === 'active';
      this.spectate = 0;
      this.acc = 0;
      this.last = performance.now();
      this.running = true;
      $('game').classList.remove('hidden');
      $('hudRole').textContent = this.role.toUpperCase();
      $('hudRole').className = this.role;
      $('hudMsg').textContent = '';
      this._toast(this.live ? 'Resynced' : 'Get ready');
      await this._initRenderer();
      this._frame = this._frame || (() => this._render());
      if (!this._raf) this._raf = requestAnimationFrame(this._frame);
    }

    async _initRenderer() {
      if (this.renderer) { this.renderer.dispose(); this.renderer = null; }
      if (new URLSearchParams(location.search).has('norender')) { $('hudMsg').textContent = 'Renderer disabled (?norender)'; return; }
      try {
        const mod = await import('/js/renderer.js');
        this.renderer = await mod.createRenderer($('gameCanvas'), this.map, this.rules);
      } catch (err) {
        console.warn('3D renderer unavailable:', err);
        $('hudMsg').textContent = '3D renderer unavailable - run "npm install" so Three.js can be served. Controls and HUD still work.';
      }
    }

    stop(restarting) {
      this.running = false;
      this.live = false;
      if (this.renderer) { this.renderer.dispose(); this.renderer = null; }
      if (!restarting) { $('game').classList.add('hidden'); if (document.pointerLockElement) document.exitPointerLock(); }
    }

    onStarted(m) {
      this.live = true;
      this.endsAt = m.endsAt;
      this.killerIds = new Set(m.killerIds || []);
      this.last = performance.now();
      this._toast(this.role === 'killer' ? 'Hunt them down' : 'Survive. Repair 4 objectives, then escape');
    }

    onPlayerStatus(m) {
      if (m.playerId === this.myId && m.status === 'eliminated') this._toast('You were eliminated - spectating');
    }

    // ---------- input ----------
    _bindInput() {
      const gameKey = (e) => this.running && ['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ShiftLeft', 'ShiftRight', 'KeyC', 'Space', 'KeyE', 'KeyZ', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Tab'].includes(e.code);
      window.addEventListener('keydown', (e) => {
        if (!gameKey(e)) return;
        e.preventDefault();
        if (e.repeat) return;
        this.keys.add(e.code);
        if (e.code === 'Space') this.latch.jump = true;
        if (e.code === 'KeyE') this.latch.interact = true;
        if (e.code === 'Tab') this.spectate++;
      });
      window.addEventListener('keyup', (e) => this.keys.delete(e.code));
      window.addEventListener('blur', () => { this.keys.clear(); this.mouseDown = false; });
      document.addEventListener('mousemove', (e) => {
        if (!this.running || document.pointerLockElement !== $('gameCanvas')) return;
        this.yaw -= e.movementX * MOUSE_SENS;
        this.pitch = Math.max(-1.5, Math.min(1.5, this.pitch - e.movementY * MOUSE_SENS));
      });
      $('gameCanvas').addEventListener('mousedown', (e) => {
        if (document.pointerLockElement !== $('gameCanvas')) { $('gameCanvas').requestPointerLock?.(); return; }
        if (e.button === 0) { this.mouseDown = true; this.latch.attack = true; }
      });
      window.addEventListener('mouseup', () => { this.mouseDown = false; });
      $('btnLeave').addEventListener('click', () => this.net.send({ t: 'leave_match' }));
    }

    _buildCmd(dtSec) {
      const k = this.keys;
      if (k.has('ArrowLeft')) this.yaw += TURN_RATE * dtSec;
      if (k.has('ArrowRight')) this.yaw -= TURN_RATE * dtSec;
      if (this.yaw > 1e3 || this.yaw < -1e3) this.yaw %= Math.PI * 2;
      let f = 0;
      if (k.has('ShiftLeft') || k.has('ShiftRight')) f |= F.SPRINT;
      if (k.has('KeyC')) f |= F.CROUCH;
      if (k.has('KeyZ')) f |= F.WALK;
      if (this.latch.jump || k.has('Space')) f |= F.JUMP;
      if (this.latch.interact || k.has('KeyE')) f |= F.INTERACT;
      if (this.role === 'killer' && (this.latch.attack || this.mouseDown)) f |= F.ATTACK;
      this.latch.jump = this.latch.interact = this.latch.attack = false;
      return { s: ++this.seq, x: (k.has('KeyD') ? 1 : 0) - (k.has('KeyA') ? 1 : 0), z: (k.has('KeyW') ? 1 : 0) - (k.has('KeyS') ? 1 : 0), y: this.yaw, p: this.pitch, f };
    }

    // ---------- fixed-step simulation (prediction) ----------
    _loop() {
      if (!this.running) return;
      const dtMs = 1000 / this.rules.tickHz;
      const now = performance.now();
      this.acc += now - this.last;
      this.last = now;
      let n = 0;
      while (this.acc >= dtMs) {
        this.acc -= dtMs;
        if (++n > 5) { this.acc = 0; break; }
        this._tick(dtMs / 1000);
      }
    }

    _tick(dtSec) {
      if (!this.live || this.auth.el || this.auth.es) return;
      const cmd = this._buildCmd(dtSec);
      this.prev = { x: this.state.x, y: this.state.y, z: this.state.z };
      if (this.auth.hid) { this.state.yaw = cmd.y; this.state.pitch = cmd.p; }
      else Sim.stepPlayer(this.state, cmd, this.map, this.rules, this.role);
      this.pending.push(cmd);
      if (this.pending.length > 120) this.pending.shift();
      this.outbox.push(cmd);
      if (this.outbox.length >= 2) this._flush();
    }

    _flush() {
      if (!this.outbox.length || !this.net.ws || this.net.ws.readyState !== 1) { this.outbox.length = 0; return; }
      while (this.outbox.length) this.net.send({ t: 'input', c: this.outbox.splice(0, 6) });
    }

    // ---------- server snapshots ----------
    onSnap(s) {
      if (!this.running) return;
      const y = s.you;
      this.auth = y;
      const wasHit = this._lastHealth !== undefined && y.h < this._lastHealth;
      this._lastHealth = y.h;
      Object.assign(this.state, { x: y.x, y: y.y, z: y.z, vy: y.vy, onGround: !!y.g, crouch: !!y.cr, stamina: y.st, exhausted: !!y.ex, regen: y.rg, haste: y.hs });
      this.pending = this.pending.filter((c) => c.s > s.ack);
      if (!y.hid && !y.el && !y.es) for (const c of this.pending) Sim.stepPlayer(this.state, c, this.map, this.rules, this.role);
      this.prev = { x: this.state.x, y: this.state.y, z: this.state.z };

      const t = performance.now();
      const seen = new Set();
      for (const [id, x, py, z, yaw, pitch, fl] of s.p) {
        seen.add(id);
        let r = this.remote.get(id);
        if (!r) { r = { id, buf: [], fl: 0 }; this.remote.set(id, r); }
        r.buf.push({ t, x, y: py, z, yaw });
        if (r.buf.length > 8) r.buf.shift();
        r.fl = fl; r.pitch = pitch;
      }
      for (const id of [...this.remote.keys()]) if (!seen.has(id)) this.remote.delete(id);

      for (const [id, prog, done] of s.o) { const o = this.objectives.get(id); if (o) { o.progress = prog; o.done = !!done; } }
      if (s.ex && !this.exitsOpen) { this.exitsOpen = true; }
      for (const e of s.ev) this._onEvent(e);
      if (wasHit) this._flash();
    }

    _onEvent(e) {
      const name = (id) => (id === this.myId ? 'You' : this.names.get(id) || 'A survivor');
      switch (e.e) {
        case 'obj': this._toast(`Objective complete (${[...this.objectives.values()].filter((o) => o.done).length}/${this.map.exitUnlock} needed)`); break;
        case 'exits': this._toast('EXITS ARE OPEN'); break;
        case 'esc': this._toast(e.id === this.myId ? 'You escaped!' : `${name(e.id)} escaped`); break;
        case 'elim': if (e.id !== this.myId) this._toast(`${name(e.id)} was eliminated`); break;
        case 'eject': if (e.id === this.myId) this._toast('You were searched out!'); break;
        case 'swing': if (this.renderer) this.renderer.swing(e.id); break;
      }
    }

    // ---------- HUD ----------
    _toast(text) {
      const el = $('hudToast');
      el.textContent = text;
      el.classList.add('show');
      clearTimeout(this._toastT);
      this._toastT = setTimeout(() => el.classList.remove('show'), 2600);
    }
    _flash() { const el = $('hudHit'); el.classList.add('on'); setTimeout(() => el.classList.remove('on'), 180); }

    _prompt() {
      if (this.auth.el || this.auth.es || !this.live) return '';
      if (this.auth.hid) return 'E: leave hiding spot';
      const s = this.state, R = this.rules.interact;
      const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
      const near = (b, cx, cz) => {
        if (Sim.distToBox(s.x, s.z, b) > R.range) return false;
        const dx = cx - s.x, dz = cz - s.z, len = Math.hypot(dx, dz);
        return len <= 0.9 || (dx * fx + dz * fz) / len >= R.minFacingDot;
      };
      const box = (ref) => this.map.colliders.find((c) => c.ref === ref);
      if (this.role === 'survivor') {
        for (const o of this.map.objectives) {
          const st = this.objectives.get(o.id);
          if (!st.done && near(box(o.id), o.x, o.z)) return this.auth.wk === o.id ? `Repairing... ${Math.round(st.progress * 100)}%` : 'Hold E: repair';
        }
      }
      for (const h of this.map.hidingSpots) if (near(box(h.id), h.x, h.z)) return this.role === 'survivor' ? 'E: hide' : 'E: search locker';
      return '';
    }

    _updateHud() {
      const a = this.auth;
      const maxH = this.rules.survivor.health, maxS = this.rules.survivor.stamina.max;
      const surv = this.role === 'survivor';
      $('hudBars').classList.toggle('hidden', !surv);
      if (surv) {
        $('hudHealthFill').style.width = `${Math.max(0, (a.h / maxH) * 100)}%`;
        $('hudStaminaFill').style.width = `${Math.max(0, (this.state.stamina / maxS) * 100)}%`;
        $('hudStaminaFill').classList.toggle('exhausted', !!this.state.exhausted);
      }
      const done = [...this.objectives.values()].filter((o) => o.done).length;
      $('hudObj').textContent = `Objectives ${done}/${this.objectives.size}${this.exitsOpen ? '  -  EXITS OPEN' : `  (need ${this.map.exitUnlock})`}`;
      const now = this.net.serverNow();
      if (!this.live) {
        const s = Math.max(0, Math.ceil((this.countdownEndsAt - now) / 1000));
        $('hudCount').textContent = s > 0 ? String(s) : '';
        $('hudTimer').textContent = '';
      } else {
        $('hudCount').textContent = '';
        const s = Math.max(0, Math.ceil((this.endsAt - now) / 1000));
        $('hudTimer').textContent = `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
      }
      $('hudPrompt').textContent = this._prompt();
      const out = a.el || a.es;
      $('hudSpec').textContent = out ? (a.es ? 'ESCAPED - spectating (Tab to switch)' : 'ELIMINATED - spectating (Tab to switch)') : '';
      $('hudCross').classList.toggle('hidden', !!out || !!a.hid);
      $('hudHidden').classList.toggle('hidden', !a.hid);
    }

    // ---------- rendering ----------
    _interpolated() {
      const t = performance.now() - INTERP_MS;
      const out = [];
      for (const r of this.remote.values()) {
        const b = r.buf;
        if (!b.length) continue;
        let a = b[0], c = b[b.length - 1];
        for (let i = b.length - 1; i > 0; i--) if (b[i - 1].t <= t) { a = b[i - 1]; c = b[i]; break; }
        const span = c.t - a.t;
        const k = span > 0 ? Math.min(1, Math.max(0, (t - a.t) / span)) : 1;
        let dy = c.yaw - a.yaw;
        while (dy > Math.PI) dy -= Math.PI * 2;
        while (dy < -Math.PI) dy += Math.PI * 2;
        out.push({ id: r.id, x: a.x + (c.x - a.x) * k, y: a.y + (c.y - a.y) * k, z: a.z + (c.z - a.z) * k, yaw: a.yaw + dy * k, pitch: r.pitch, fl: r.fl, killer: this.killerIds.has(r.id) });
      }
      return out;
    }

    _cameraPose(players) {
      const P = this.rules.player;
      if (this.auth.el || this.auth.es) {
        const alive = players.filter((p) => !(p.fl & 4));
        if (alive.length) {
          const t = alive[((this.spectate % alive.length) + alive.length) % alive.length];
          return { x: t.x, y: t.y + P.eyeStand, z: t.z, yaw: t.yaw, pitch: t.pitch || 0, followId: t.id };
        }
      }
      const a = Math.min(1, this.acc / (1000 / this.rules.tickHz));
      const s = this.state;
      return { x: this.prev.x + (s.x - this.prev.x) * a, y: this.prev.y + (s.y - this.prev.y) * a + (s.crouch ? P.eyeCrouch : P.eyeStand), z: this.prev.z + (s.z - this.prev.z) * a, yaw: this.yaw, pitch: this.pitch };
    }

    _render() {
      this._raf = requestAnimationFrame(this._frame);
      if (!this.running) return;
      this._updateHud();
      if (!this.renderer) return;
      const players = this._interpolated();
      const cam = this._cameraPose(players);
      this.renderer.setCamera(cam);
      this.renderer.setPlayers(players, cam.followId);
      for (const [id, o] of this.objectives) this.renderer.setObjective(id, o.progress, o.done);
      this.renderer.setExitsOpen(this.exitsOpen);
      this.renderer.render();
    }
  }

  window.Game = Game;
})();
