// Three.js renderer for the match. ES module; loaded on demand by game.js so the game still works if
// Three.js is not installed. Draws exactly the geometry the server collides against (map.colliders).
import * as THREE from 'three';

const COLORS = { wall: 0x4b4d57, crate: 0x6d4b2c, locker: 0x2c5a58, objective: 0x7a1f1f };

export async function createRenderer(canvas, map, rules) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));

  const scene = new THREE.Scene();
  const L = map.lighting || {};
  scene.background = new THREE.Color(L.fog ?? 0x05060a);
  scene.fog = new THREE.FogExp2(L.fog ?? 0x05060a, L.fogDensity ?? 0.035);

  const camera = new THREE.PerspectiveCamera(75, 1, 0.05, 200);
  camera.rotation.order = 'YXZ';
  scene.add(camera);
  scene.add(new THREE.AmbientLight(L.ambient ?? 0x2a3140, 1.6));
  const moon = new THREE.DirectionalLight(0x8899bb, 0.5);
  moon.position.set(-20, 40, 10);
  scene.add(moon);
  // Flashlight: a spotlight riding on the camera.
  const flash = new THREE.SpotLight(0xfff0cc, 60, 35, Math.PI / 6, 0.5, 1.4);
  flash.position.set(0, 0, 0);
  flash.target.position.set(0, 0, -1);
  camera.add(flash, flash.target);

  // ---- static geometry ----
  const [bx0, bz0] = map.bounds.min, [bx1, bz1] = map.bounds.max;
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(bx1 - bx0 + 4, bz1 - bz0 + 4), new THREE.MeshLambertMaterial({ color: 0x1a1d1a }));
  floor.rotation.x = -Math.PI / 2;
  floor.position.set((bx0 + bx1) / 2, -0.001, (bz0 + bz1) / 2);
  scene.add(floor);

  const mats = {};
  const matFor = (kind) => (mats[kind] ||= new THREE.MeshLambertMaterial({ color: COLORS[kind] ?? 0x555555 }));
  const objectiveMeshes = new Map();
  for (const c of map.colliders) {
    const w = c.max[0] - c.min[0], h = c.max[1] - c.min[1], d = c.max[2] - c.min[2];
    const isObjective = c.kind === 'objective';
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), isObjective ? new THREE.MeshLambertMaterial({ color: COLORS.objective, emissive: 0x330000 }) : matFor(c.kind));
    mesh.position.set((c.min[0] + c.max[0]) / 2, (c.min[1] + c.max[1]) / 2, (c.min[2] + c.max[2]) / 2);
    scene.add(mesh);
    if (isObjective) objectiveMeshes.set(c.ref, mesh);
  }
  const exitMeshes = map.exits.map((e) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(e.hx * 2, 3.5, e.hz * 2), new THREE.MeshBasicMaterial({ color: 0x992222, transparent: true, opacity: 0.28 }));
    m.position.set(e.x, 1.75, e.z);
    scene.add(m);
    return m;
  });

  // ---- players ----
  const survivorMat = new THREE.MeshLambertMaterial({ color: 0x4f7d6a });
  const killerMat = new THREE.MeshLambertMaterial({ color: 0x9c1f1f });
  const headMat = new THREE.MeshLambertMaterial({ color: 0xd8c3a5 });
  const swingMat = new THREE.MeshLambertMaterial({ color: 0xff5533, emissive: 0x551100 });
  const avatars = new Map();
  const swings = new Map();
  function makeAvatar(killer) {
    const g = new THREE.Group();
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 1.2, 12), killer ? killerMat : survivorMat);
    body.position.y = 0.6;
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 10), headMat);
    head.position.y = 1.45;
    g.add(body, head);
    if (killer) g.scale.setScalar(1.12);
    scene.add(g);
    return g;
  }

  function resize() {
    const w = canvas.clientWidth || window.innerWidth, h = canvas.clientHeight || window.innerHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize);
  resize();

  return {
    setCamera(c) {
      camera.position.set(c.x, c.y, c.z);
      camera.rotation.set(c.pitch, c.yaw, 0);
    },
    setPlayers(list, hideId) {
      const live = new Set();
      for (const p of list) {
        live.add(p.id);
        let a = avatars.get(p.id);
        if (!a || a.killer !== p.killer) {
          if (a) scene.remove(a.g);
          a = { g: makeAvatar(p.killer), killer: p.killer };
          avatars.set(p.id, a);
        }
        a.g.visible = p.id !== hideId && !(p.fl & 4);
        a.g.position.set(p.x, p.y, p.z);
        a.g.rotation.y = p.yaw;
        const crouch = p.fl & 1;
        a.g.scale.y = (p.killer ? 1.12 : 1) * (crouch ? 0.72 : 1);
        if (swings.has(p.id) && performance.now() > swings.get(p.id)) swings.delete(p.id);
        a.g.children[0].material = p.killer && swings.has(p.id) ? swingMat : (p.killer ? killerMat : survivorMat);
      }
      for (const [id, a] of avatars) if (!live.has(id)) { scene.remove(a.g); avatars.delete(id); }
    },
    swing(id) { swings.set(id, performance.now() + 250); },
    setObjective(id, progress, done) {
      const m = objectiveMeshes.get(id);
      if (!m) return;
      const c = done ? 0x2f9e5b : new THREE.Color(0x8a2020).lerp(new THREE.Color(0xd9a21b), progress);
      m.material.color.set(c);
      m.material.emissive.set(done ? 0x0a3a1c : 0x330000);
    },
    setExitsOpen(open) {
      for (const m of exitMeshes) { m.material.color.set(open ? 0x22cc66 : 0x992222); m.material.opacity = open ? 0.4 : 0.28; }
    },
    render() { renderer.render(scene, camera); },
    dispose() { window.removeEventListener('resize', resize); renderer.dispose(); },
  };
}
