'use strict';
const net = new Net();
const game = new Game(net);
window.__game = game; // handy for debugging in the console
const $ = (id) => document.getElementById(id);
let view = { state: 'connecting', match: null };

const log = (s) => { $('log').textContent = `${new Date().toLocaleTimeString()}  ${s}\n` + $('log').textContent; };

function render() {
  const { state, match } = view;
  $('play').disabled = state !== 'lobby';
  $('secondary').disabled = !(state === 'queued' || state === 'countdown' || state === 'active');
  $('secondary').textContent = state === 'queued' ? 'Cancel' : 'Leave match';
  $('role').textContent = '';
  $('role').className = '';
  $('roster').innerHTML = '';
  if (match && match.you) {
    if (state !== 'ended') { $('role').textContent = match.you.role.toUpperCase(); $('role').className = match.you.role; }
    const rows = state === 'ended' && match.results
      ? match.results.players.map((p) => [p.name, `${p.role} - ${p.outcome}`])
      : match.roster.map((p) => [p.name + (p.playerId === match.you.playerId ? ' (you)' : ''), p.status]);
    for (const [a, b] of rows) {
      const li = document.createElement('li');
      const l = document.createElement('span'); l.textContent = a;
      const r = document.createElement('span'); r.className = 'dim'; r.textContent = b;
      li.append(l, r); $('roster').append(li);
    }
  }
}

function setStatus(s) { $('status').textContent = s; }

net.on('welcome', (m) => { view.state = m.state === 'queued' ? 'lobby' : m.state; if (view.state === 'lobby') { view.match = null; setStatus('Ready. Press Play.'); } render(); });
net.on('_close', () => { setStatus('Connection lost - reconnecting\u2026'); });
net.on('lobby', () => { game.stop(); view = { state: 'lobby', match: view.state === 'ended' ? view.match : null }; setStatus('Back in the lobby. Press Play.'); $('timer').textContent = ''; render(); });
net.on('queued', (m) => { view.state = 'queued'; setStatus(`Searching for a match\u2026 (${m.queued} in queue, need ${m.minPlayers})`); render(); });
function enterMatch(m) { view = { state: m.state, match: m }; if (m.state === 'ended') game.stop(); else game.start(m); setStatus(m.state === 'ended' ? `Match over: ${m.results.winner} win` : m.state === 'countdown' ? 'Match found - get ready' : 'Match in progress'); render(); }
net.on('match_found', (m) => { log('match found'); enterMatch(m); });
net.on('match_resync', (m) => { log('resynced to match'); enterMatch(m); });
net.on('snap', (m) => game.onSnap(m));
net.on('match_started', (m) => { game.onStarted(m); view.state = 'active'; view.match.endsAt = m.endsAt; view.match.state = 'active'; setStatus('Match in progress'); render(); });
net.on('match_ended', (m) => { game.stop(); view.state = 'ended'; view.match.results = m.results; setStatus(`Match over: ${m.results.winner} win (${m.results.reason})`); $('timer').textContent = ''; render(); });
net.on('match_aborted', (m) => { game.stop(); log('match aborted: ' + m.reason); view = { state: 'lobby', match: null }; setStatus('Match cancelled (' + m.reason + '). Requeuing\u2026'); render(); });
net.on('player_status', (m) => {
  game.onPlayerStatus(m);
  const p = view.match && view.match.roster.find((x) => x.playerId === m.playerId);
  if (p) { p.status = m.status; render(); }
  log(`player ${m.status}`);
});
net.on('error', (m) => log('server error: ' + m.error));

$('play').onclick = () => {
  const n = $('name').value.trim();
  if (n) sessionStorage.setItem('hunt.name', n);
  net.send({ t: 'play' });
};
$('secondary').onclick = () => {
  if (view.state === 'queued') { net.send({ t: 'cancel_queue' }); } else { net.send({ t: 'leave_match' }); }
};

setInterval(() => {
  const m = view.match;
  if (!m) return;
  const target = view.state === 'countdown' ? m.countdownEndsAt : view.state === 'active' ? m.endsAt : null;
  if (!target) return;
  const s = Math.max(0, Math.ceil((target - net.serverNow()) / 1000));
  $('timer').textContent = view.state === 'countdown' ? `Starts in ${s}` : `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}, 200);
